<?php
class Globals
{
    public function get_message($type, $title, $content)
    {
        ?>
        <script>
            jQuery.msgBox({
                title: "<?php echo $title; ?>",
                content:"<?php echo $content; ?>",
                type:"<?php echo $type; ?>"
            });
        </script>
        <?php
    }

    public function get_dateformat($strDate, $format)
    {
        $date=date_create($strDate);
        return date_format($date, $format);
    }

    public function get_the_content($content)
    {
        return nl2br($content);
    }

    public function sendMail($to, $subject, $content)
    {
        require_once(APPPATH.'/libraries/phpmailer/class.phpmailer.php');
        require_once(APPPATH.'/libraries/phpmailer/class.smtp.php');
        $mail = new PHPMailer();

        $mail->IsSMTP(); // set mailer to use SMTP

        $mail->Host='smtp.mailgun.org';
        $mail->Port = '587'; // set the port to use
        $mail->SMTPAuth = true; // turn on SMTP authentication

        $mail->SMTPSecure='tls';
        $mail->Username = 'postmaster@sender.sendervn.com'; // your SMTP username or your gmail username
        $mail->Password = 'eb6e9caaf327c676c9e4d06e1ee38746-9ce9335e-e816d3b1'; // your SMTP password or your gmail password
        $mail->Timeout = 3600;

        $mail->From = 'no-reply@nguonnhadat.com.vn';
        $mail->FromName = 'Nguồn Nhà Đất';
        // Name to indicate where the email came from when the recepient received
        $mail->AddAddress($to);
        $mail->CharSet = 'UTF-8';
        $mail->WordWrap = 50; // set word wrap
        $mail->IsHTML(true); // send as HTML
        $mail->Subject = $subject;
        $mail->Body = $content; //HTML Body

        $mail->SMTPDebug = 0;
        if(!$mail->Send())
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    function custom_cut($str,$number){
        $excerpt = $str;
        $excerpt = preg_replace(" (\[.*?\])",'',$excerpt);
        $excerpt = explode("&nbsp;", $excerpt);
        $new_str = "";
        $d=0;
        if(count($excerpt)<$number) $number = count($excerpt);
        for($i=0;$i<$number;$i++){
            $excerpt[$i] = strip_tags($excerpt[$i]);
            $d++;
            if($d>1) $new_str.=" ";
            $new_str.=$excerpt[$i];
        }
        if($d<count($excerpt)-1) {
            $new_str.="...";
        }
        return $new_str;
    }

    function change_content_ckeditor($str){
        $excerpt = $str;
        $excerpt = preg_replace(" (\[.*?\])",'',$excerpt);
        $excerpt = explode("&nbsp;", $excerpt);
        $new_str = "";
        $d=0;
        foreach($excerpt as $item){
            $d++;
            if($d>1) $new_str.=" ";
            $new_str.=$item;
        }
        return $new_str;
    }

    function current_url()
    {
        $CI =& get_instance();
        $url = $CI->config->site_url($CI->uri->uri_string());
        return $_SERVER['QUERY_STRING'] ? $url.'?'.$_SERVER['QUERY_STRING'] : $url;
    }

    function my_export($name,$title,$th_array,$tr_array){
        // Bước 1:
        // Lấy dữ liệu từ database

        // Bước 2: Import thư viện phpexcel
        require_once(APPPATH.'libraries/PHPExcel.php');

        // Bước 3: Khởi tạo đối tượng mới và xử lý
        $PHPExcel = new PHPExcel();

        // Bước 4: Chọn sheet - sheet bắt đầu từ 0
        $PHPExcel->setActiveSheetIndex(0);

        // Bước 5: Tạo tiêu đề cho sheet hiện tại
        $PHPExcel->getActiveSheet()->setTitle($title);

        // Bước 6: Tạo tiêu đề cho từng cell excel,
        // Các cell của từng row bắt đầu từ A1 B1 C1 ...
        $PHPExcel->getActiveSheet()->setCellValue('A1', 'STT');
        foreach ($th_array as $key => $item) {
            $PHPExcel->getActiveSheet()->setCellValue($key.'1', $item);
        }

        // Bước 7: Lặp data và gán vào file
        // Vì row đầu tiên là tiêu đề rồi nên những row tiếp theo bắt đầu từ 2
        $rowNumber = 2;
        $d= 1;
        if($tr_array){
            foreach($tr_array as $tr_item){
                $PHPExcel->getActiveSheet()->setCellValue('A'.$rowNumber, $d);
                foreach ($tr_item as $key => $td) {
                    $PHPExcel->getActiveSheet()->setCellValue($key.$rowNumber, $td);
                }

                // Tăng row lên để khỏi bị lưu đè
                $rowNumber++;
                $d++;
            }
        }
        // Bước 8: Khởi tạo đối tượng Writer
        $objWriter = PHPExcel_IOFactory::createWriter($PHPExcel, 'Excel5');

        // Bước 9: Trả file về cho client download
        header('Content-Type: application/vnd.ms-excel');
        $file_name = $name."_".time();
        header('Content-Disposition: attachment;filename="'.$file_name.'.xls"');
        header('Cache-Control: max-age=0');
        if (isset($objWriter)) {
            $objWriter->save('php://output');
        }
    }

    function white_file_employee($user_info,$action,$name="history.txt"){
        $path = FCPATH.'history';
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        $path = $path.'/'.$name;
        $content = json_decode(file_get_contents($path));
        $content[] = array(
            'id' => time(),
            'fullname' => $user_info['fullname'],
            'username' => $user_info['username'],
            'email_address' => $user_info['email_address'],
            'user_phone' => $user_info['user_phone'],
            'user_type' => $user_info['user_type'],
            'time' => time(),
            'action' => $action
        );
        $new_content = json_encode( $content );
        $fp = fopen($path,"wb");
        fwrite($fp,$new_content);
        fclose($fp);
    }

    function re_white_file($content,$name="history.txt"){
        $path = FCPATH.'history';
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        $path = $path.'/'.$name;
        $new_content = json_encode( $content );
        $fp = fopen($path,"wb");
        fwrite($fp,$new_content);
        fclose($fp);
    }

    function get_history($name="history.txt"){
        $path = FCPATH.'history/'.$name;
        $content = json_decode(file_get_contents($path));
        return $content;
    }

    function change_to_slug($str) {
        $str = trim(mb_strtolower($str));
        $str = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $str);
        $str = preg_replace('/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/', 'e', $str);
        $str = preg_replace('/(ì|í|ị|ỉ|ĩ)/', 'i', $str);
        $str = preg_replace('/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/', 'o', $str);
        $str = preg_replace('/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/', 'u', $str);
        $str = preg_replace('/(ỳ|ý|ỵ|ỷ|ỹ)/', 'y', $str);
        $str = preg_replace('/(đ)/', 'd', $str);
        $str = preg_replace('/\&/', 'va', $str);
        $str = preg_replace('/[^a-z0-9-\s]/', '', $str);
        $str = preg_replace('/([\s]+)/', '-', $str);
        return $str;
    }

    function change_to_number($str) {
        $str = trim(mb_strtolower($str));
        $str = preg_replace('/(tỷ)/', '000000000', $str);
        $str = preg_replace('/(triệu)/', '000000', $str);
        $str = preg_replace('/(ngàn|nghìn)/', '000', $str);
        
        

        return $str;
    }
}
?>