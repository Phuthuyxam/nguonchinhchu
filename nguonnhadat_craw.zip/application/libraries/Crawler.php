<?php
Class Crawler
{
	public function __construct() {
		require_once APPPATH.'/libraries/simple_html_dom.php';
	}

	public function get_dom_single_page($url)
	{


		$user_agent = 'Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

		$options = array(

			CURLOPT_CUSTOMREQUEST => "GET",        //set request type post or get
			CURLOPT_POST => false,        //set to GET
			CURLOPT_USERAGENT => $user_agent, //set user agent
			CURLOPT_COOKIEFILE => "cookie.txt", //set cookie file
			CURLOPT_COOKIEJAR => "cookie.txt", //set cookie jar
			CURLOPT_RETURNTRANSFER => true,     // return web page
			CURLOPT_HEADER => false,    // don't return headers
			CURLOPT_FOLLOWLOCATION => true,     // follow redirects
			CURLOPT_ENCODING => "",       // handle all encodings
			CURLOPT_AUTOREFERER => true,     // set referer on redirect
			CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
			CURLOPT_TIMEOUT => 120,      // timeout on response
			CURLOPT_MAXREDIRS => 10,       // stop after 10 redirects
			CURLOPT_SSL_VERIFYPEER => false
		);

		$ch = curl_init($url);
		curl_setopt_array($ch, $options);
		$content = curl_exec($ch);
		$err = curl_errno($ch);
		$errmsg = curl_error($ch);
		$header = curl_getinfo($ch);
		curl_close($ch);
		$header['errno'] = $err;
		$header['errmsg'] = $errmsg;
		$header['content'] = $content;
		return $header['content'];
	}

	public function get_list_url($url, $elemment, $domain = NUll)
	{

		$html = $this->get_dom_single_page($url);

		$html = str_get_html($html);

		$get = $elemment . ' a';

		$url_arr = array();

		foreach ($html->find($get) as $key => $dom) {

			$url = $domain . $dom->href;

			$url_arr[] = $url;

		}
		return $url_arr;
	}

	public function get_data($html, array $data_array, $domain = NUll)
	{

		$str_html = str_get_html($html);

		$result = array();

		foreach ($data_array as $index => $elemment) {

			$data = json_decode($elemment);
			// echo "<pre>";
			// print_r($data);
			// echo "</pre>";
			$attr = $data->element;

			$count = $data->count;

			// $convert = $data->convert;

			// $loop = $data->loop;

			if (!isset($data->convert) || empty($data->convert)) {
				if (!isset($data->loop) || empty($data->loop)) {
					//$main = $str_html->find('div.pm-title',0);
					// echo $main;
					$value = $str_html->find($attr, $count);
					// $value = str;
					$result[$index] = trim($value->plaintext);

				} else {
					$gallery_arr = array();

					foreach ($str_html->find($attr) as $key => $value) {
						$gallery_arr[$key] = $domain . $value->src;
					}

					$result[$index] = $gallery_arr;

					$result[$index] = array_unique($result[$index]);

				}

				// isset loop

			} else {

				if (!isset($data->loop) || empty($data->loop)) {
					// unset loop data ..
					$value = $str_html->find($attr, $count);
					// // echo  $str_html;
					$value = html_entity_decode($value);
					$result[$index] = $value;
				} else {
					//isset loop data and data-covert

					$loop_arr = array();
					$str_loop = $str_html->find($attr, $count);


					foreach ($str_loop->find($data->loop) as $key => $value) {

						$value = html_entity_decode($value);
						$loop_arr[$key] = $value;


					}

					$result[$index] = $loop_arr;


				}


			}

			// custom alo nha dat
			if (isset($data->loop_alonhadat) && !empty($data->loop_alonhadat)) {

				$loop_arr = array();
				$str_loop = $str_html->find($data->loop_alonhadat, $count);
				$main_content = $str_loop->find($attr);

				for ($i = 0; $i < count($main_content); $i++) {

					if ($i % 2 == 0) {
						$key = $main_content[$i]->plaintext;
						$value = html_entity_decode($main_content[$i + 1]);
						$loop_arr[$key] = trim($value);
					}
				}

				$result[$index] = $loop_arr;
			}

			// custom gallery muaban.net

			if (isset($data->loop_muaban) && !empty($data->loop_muaban)) {

				// $loop_arr = array();
				// $str_loop = $str_html->find($data->loop_muaban,$count);
				// $main_content = $str_loop->find($attr);

				$gallery_arr = array();

				foreach ($str_html->find($attr) as $key => $value) {
					if ($key == 0) {
						$gallery_arr[$key] = $domain . $value->src;
					} else {
						// $gallery_arr[$key] = $domain.$value->'data-src';
						$gallery_arr[$key] = $domain . $value->attr['data-src'];
					}
				}

				$result[$index] = $gallery_arr;
			}

			// custom gallery nhadat24h

			if (isset($data->loop_nhadat24h_gallery) && !empty($data->loop_nhadat24h_gallery)) {

				$gallery_arr = array();

				foreach ($str_html->find($attr) as $key => $value) {

					$gallery_arr[$key] = $domain . $value->href;


				}

				$result[$index] = $gallery_arr;
			}

			//custom table info nhadat24h.com
			if (isset($data->loop_nhadat24h_tbs) && !empty($data->loop_nhadat24h_tbs)) {

				$tbs_info = array();

				foreach ($str_html->find($attr) as $key => $value) {

					// $gallery_arr[$key] = $domain.$value->href;
					$node = $value->find('span', 0);
					$node = $node->plaintext;

					$node_index = $value->find('text', 1)->plaintext;

					// echo $node;

					$tbs_info[$node] = $node_index;


				}
				$result[$index] = $tbs_info;
			}

			//map lat

			if (isset($data->map_) && !empty($data->map_)) {

				$lat = $data->map_;

				if (isset($lat) && !empty($lat)) {

					$map_lat = $str_html->find($attr, 0);


					$map_lat = $map_lat->attr['value'];
					$map_lat = html_entity_decode($map_lat);

					$result[$index] = $map_lat;

					// echo $map_lat;
				}


			}

			//custom i - nhadat

			if (isset($data->loop_i_nha_dat) && !empty($data->loop_i_nha_dat)) {

				$table_arr = array();
				$main_arr = $str_html->find($attr);
				foreach ($str_html->find($attr) as $key => $value) {

					if ($key % 2 == 0) {
						$arr_index = html_entity_decode($main_arr[$key]);
						$table_arr[$arr_index] = html_entity_decode($main_arr[$key + 1]);
					}
				}

				$result[$index] = $table_arr;
			}

			// findtext


			if (isset($data->findtext) && !empty($data->findtext)) {

				$value = $str_html->find($attr, $count);

				$find_text_value = $value->find('text', $data->findtext);

				$find_text_value = $find_text_value->plaintext;

				$find_text_value = trim($find_text_value);

				// echo $value;
				// $value = str;
				// echo $data->findtext;
				// $value = $value->find('text',$data->findtext);
				// $result[$index] = trim($value->plaintext);

				$result[$index] = $find_text_value;
			}

			//custom table info timmuanhadat
			if (isset($data->loop_timmuanhadat_tbs) && !empty($data->loop_timmuanhadat_tbs)) {

				$tbs_info = array();

				foreach ($str_html->find($attr) as $key => $value) {

					// $gallery_arr[$key] = $domain.$value->href;
					$node = $value->find('td', 0);
					$node = $node->plaintext;

					$node_index = $value->find('text', 1)->plaintext;

					// echo $node;

					$tbs_info[$node] = $node_index;


				}
				$result[$index] = $tbs_info;
			}

			// custom title mogi
			if(isset($data->title_mogi)&&!empty($data->title_mogi)&&!isset($data->element)) {
				$title_mogi = $data->title_mogi;
				$count = $data->count;
				// unset loop data ..
				$value = $str_html->find($title_mogi, $count);
//            $value = html_entity_decode($value);
				$result[$index] = $value->attr['content'];
			}
		}
		// custom homedy
		if(isset($data->loop_homedy)&&!empty($data->loop_homedy)) {
			$gallery_arr = array();



			foreach ($str_html->find($attr) as $key => $value) {
				//$gallery_arr[$key] = $value->attr['data-original'];
				echo $value;
			}

			$result[$index] = $gallery_arr;

//        $result[$index] = array_unique($result[$index]);
		}

		// custom timkiemnhadat
		if(isset($data->loop_timkiemnhadat_tbs)&&!empty($data->loop_timkiemnhadat_tbs)) {
			$tbs_info = array();
			foreach ($str_html->find($attr,0) as $key => $value) {
				// $gallery_arr[$key] = $domain.$value->href;
				$node = $value->find('.para', 0);
//            $node = $node->plaintext;
				$node = html_entity_decode($node);
				$node_index = $value->find('text', 0)->plaintext;
				// echo $node;
				$tbs_info[trim($node_index)] = trim($node);
			}
			$result[$index] = $tbs_info;
		}

		// custom contact
		if(isset($data->loop_timkiemnhadat_contact)&&!empty($data->loop_timkiemnhadat_contact)) {
			$tbs_info = array();
			foreach ($str_html->find($attr) as $key => $value) {
//            echo $value;
				// $gallery_arr[$key] = $domain.$value->href;
				$node = $value->find('span', 0);
//            $node = $node->plaintext;
				$node = html_entity_decode($node);
				$node_index = $value->find('text', 0)->plaintext;
				// echo $node;
				$tbs_info[trim($node_index)] = trim($node);
			}
			$result[$index] = $tbs_info;
		}

		if(isset($data->loop_kenhbatdongsan)&&!empty($data->loop_kenhbatdongsan)) {
			$tbs_info = array();
			foreach ($str_html->find($attr) as $key => $value) {
//            echo $value;
				// $gallery_arr[$key] = $domain.$value->href;
				$node = $value->find('text', 1);
//            $node = $node->plaintext;
				$node = html_entity_decode($node);
				$node_index = $value->find('span', 0)->plaintext;
				// echo $node;
				$tbs_info[trim($node_index)] = trim($node);
			}
			$result[$index] = $tbs_info;
		}



		// echo "<pre>";
		// print_r($result);
		// echo "</pre>";

		return $result;


	}
}
?>