<?php
$controller = $this->router->fetch_class();
$method = $this->router->fetch_method();
?>
<ul class="list-inline text-right" style="margin-bottom: 0px; padding-top: 5px; color: #fff; font-family: Tahoma; font-size: 12px;">
    <li><?php echo $marketData; ?></li>
</ul>
