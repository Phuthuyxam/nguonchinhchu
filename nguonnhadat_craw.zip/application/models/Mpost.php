<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mpost extends CI_Model {

	protected $_table = 'posts';
    public function __construct()
    {
        parent::__construct();
    }

    /* ==================  Admin ==================== */
    public function get_all_post($filter=array(), $keyword='', $category=array()){

    	$this->db->order_by('timestamp', 'desc');
    	if (!empty($filter))
        {
            $this->db->where($filter);
        }

        if (!empty($keyword))
        {
            $this->db->like('post_title', $keyword);
            $this->db->or_like('post_content', $keyword);
        }

        if (!empty($category))
        {
            $this->db->where_in('cate_id', $category);
        }

    	return $this->db->get($this->_table)->result_array();
    }

    public function get_list_post_by($type, $filter=array(), $keyword='', $category=array(), $per_page, $offset)
    {
        if (!empty($filter))
        {
            $this->db->where($filter);
        }

        if (!empty($keyword))
        {
            $this->db->like('post_title', $keyword);
            $this->db->or_like('post_content', $keyword);
            $this->db->or_like('contact', $keyword);
        }

        if (!empty($category))
        {
            $this->db->where_in('cate_id', $category);
        }

        $this->db->where('for_vip_user', $type);

        $this->db->where('active', 1);

        $this->db->limit($per_page, $offset);

        return $this->db->get($this->_table)->result_array();

    }

    //Lấy số lượng các post đã kích hoạt
    public function get_number_post_active($type, $filter=array(), $keyword='', $category=array())
    {
        if (!empty($filter))
        {
            $this->db->where($filter);
        }

        if (!empty($keyword))
        {
            $this->db->like('post_title', $keyword);
            $this->db->or_like('post_content', $keyword);
            $this->db->or_like('contact', $keyword);
        }

        if (!empty($category))
        {
            $this->db->where_in('cate_id', $category);
        }

        $this->db->where('for_vip_user', $type);

        $this->db->where('active', 1);

        return $this->db->get($this->_table)->num_rows();
    }

    public function get_list_post_ad($type,$filter=array(), $keyword='')
    {
          if (!empty($filter))
        {
            $this->db->where($filter);
        }

        if (!empty($keyword))
        {
            $this->db->like('post_title', $keyword);
            $this->db->or_like('post_content', $keyword);
            $this->db->or_like('contact', $keyword);
        }

        $this->db->where('for_vip_user', $type);
        return $this->db->get($this->_table)->result_array();
    }

    // Insert
    public function insert($data){
    	$this->db->insert($this->_table, $data);
        return $this->db->insert_id();
    }

     //Check post by id
    public function check_post_id($post_id){
    	$this->db->where("post_id", $post_id);
    	return $this->db->get($this->_table)->num_rows();
    }

    //Get post by
    public function get_post_by($field,$value){
    	$this->db->where($field, $value);
    	return $this->db->get($this->_table)->row_array();
    }

    // Update 
    public function update($post_id, $data){
        $this->db->where("post_id", $post_id);
        return $this->db->update($this->_table, $data);
    }



    // Delete 
    public function delete($post_id){
        $this->db->where("post_id",$post_id);
        return $this->db->delete($this->_table);
    }

    // Check exists post_title
    public function check_post_title_exists($post_title,$post_id=0){
        $this->db->where('post_id <>', $post_id)->where("post_title", $post_title);
        return $this->db->get($this->_table)->num_rows();
    }

    /* ================== Member =================== */
    //Get all post
    public function mem_get_all_post(){
        $this->db->where("active",1);
        $this->db->order_by("timestamp", "desc");
        return $this->db->get($this->_table)->result_array();
    }

    //Get post by
    public function mem_get_post_by($field,$value){
        $this->db->where($field, $value)->where("active",1);
        $this->db->order_by("timestamp", "desc");
        return $this->db->get($this->_table)->row_array();
    }

    //Get post feadtured
    public function mem_get_post_featured(){
        $this->db->where("feadtured_post", 1)->where("active",1);
        $this->db->order_by("timestamp", "desc");
        return $this->db->get($this->_table)->result_array();
    }

     //Check post by id
    public function mem_check_post_id($post_id){
        $this->db->where("post_id", $post_id)->where("active",1);
        return $this->db->get($this->_table)->num_rows();
    }

    public function insert_post_images($data)
    {
        $this->db->insert('post_image', $data);
        return $this->db->insert_id();
    }

    public function delete_post_images($post_id)
    {
        $this->db->where('post_id', $post_id);
        $this->db->delete('post_image');
    }

    public function get_post_images($post_id)
    {
        $this->db->where('post_id', $post_id);
        return $this->db->get('post_image')->result_array();
    }

    public function insert_save_post($data)
    {
        $this->db->insert('post_save', $data);
        return $this->db->insert_id();
    }

    public function delete_save_post($post_id, $user_id)
    {
        $this->db->where(array('post_id'=>$post_id, 'user_id'=>$user_id));
        $this->db->delete('post_save');
    }

    public function get_number_save_post($post_id, $user_id)
    {
        $this->db->where(array('post_id'=>$post_id, 'user_id'=>$user_id));
        return $this->db->get('post_save')->num_rows();
    }

    public function get_all_save_post($user_id)
    {
        $this->db->where(array('user_id'=>$user_id));
        return $this->db->get('post_save')->result_array();
    }

    public function insert_post_read($data)
    {
        $this->db->insert('post_read', $data);
        return $this->db->insert_id();
    }

    public function get_post_read($user_id, $post_id)
    {
        $this->db->where(array('user_id'=>$user_id, 'post_id'=>$post_id));
        return $this->db->get('post_read')->num_rows();
    }
    public function get_product_price()
    {
        $this->db->select('price');
        return $this->db->get($this->_table)->result_array();
    }
    public function get_province_id_by_name($province_name)
    {
    	$this->db->like('name', $province_name);
	    return $this->db->get('province')->row_array();
    }
    public function get_district_id_by_name($district_name)
    {
        $this->db->like('name', $district_name);
        return $this->db->get('district')->row_array();
    }


}

/* End of file Muser.php */
/* Location: ./application/models/Muser.php */