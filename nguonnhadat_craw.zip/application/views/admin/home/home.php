<?php require_once APPPATH.'/views/admin/header.php'; ?>

<div class="row">
	<?php
	$login = $this->session->get_userdata();
	$info_admin_check = $login['admin_info'];

		?>

		<div class="col-md-12 col-lg-6 col-xl-6">
			<section class="panel panel-featured-left panel-featured-secondary">
				<div class="panel-body">
					<div class="widget-summary">
						<div class="widget-summary-col widget-summary-col-icon">
							<div class="summary-icon bg-secondary">
								<i class="fa fa-users"></i>
							</div>
						</div>
						<div class="widget-summary-col">
							<div class="summary">
								<div class="info">
									<strong class="amount"><?php echo $total['user']; ?></strong>
								</div>
								<h4 class="title">Người dùng</h4>
							</div>
							<div class="summary-footer">
								<a href="<?php echo base_url(); ?>admin/user" class="text-muted text-uppercase">(Xem tất cả)</a>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>

		<div class="col-md-12 col-lg-6 col-xl-6">
			<section class="panel panel-featured-left panel-featured-tertiary">
				<div class="panel-body">
					<div class="widget-summary">
						<div class="widget-summary-col widget-summary-col-icon">
							<div class="summary-icon bg-tertiary">
								<i class="fa fa-file-o"></i>
							</div>
						</div>
						<div class="widget-summary-col">
							<div class="summary">
								<div class="info">
									<strong class="amount"><?php echo $total['post']; ?></strong>
								</div>
								<h4 class="title">Tin đăng</h4>
							</div>
							<div class="summary-footer">
								<a href="<?php echo base_url(); ?>admin/post" class="text-muted text-uppercase">(Xem tất cả)</a>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>

</div>

<?php require_once APPPATH.'/views/admin/footer.php'; ?>