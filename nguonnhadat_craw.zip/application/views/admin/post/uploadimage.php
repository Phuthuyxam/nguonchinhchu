<?php
function url(){
    if(isset($_SERVER['HTTPS'])){
        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
    }
    else{
        $protocol = 'http';
    }
    return $protocol . "://" . $_SERVER['HTTP_HOST'];
}
// Sử dụng vòng lặp for để lưu từng file trong mảng
foreach($_FILES['file']['name'] as $name => $value)
{
	$name_img = stripslashes($_FILES['img_file']['name'][$name]);
	$source_img = $_FILES['img_file']['tmp_name'][$name];
	$path_img = "upload/" . $name_img;
	move_uploaded_file($source_img, $path_img);

	echo '<input type="text" class="bui" type="hidden" name="images[]" value="'.base_url()."/buido"."/".$path_img.'">' ;
}

?>
