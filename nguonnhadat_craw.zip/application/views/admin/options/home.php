<?php require_once APPPATH.'/views/admin/header.php'; ?>

<?php require_once APPPATH.'/views/admin/footer.php'; ?>