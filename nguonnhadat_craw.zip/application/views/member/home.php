<?php
require_once APPPATH.'/views/member/header.php';
require_once APPPATH.'/views/member/block/slideshow.php';
?>
<?php echo validation_errors(); ?>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                <h1 class="title">Giải pháp nguồn nhà tuyệt vời dành cho Nghề Môi Giới</h1>
                <p>
                    Với kinh nghiệm Môi giới nhà đất hơn 10 năm qua, chúng tôi thấu hiểu nỗi lòng của các anh em trong nghề. Các bạn trăn trở gặp khó khăn vì không có một nguồn nhà phong phú để bán, hay cảm thấy quá tốn thời gian khi phải đi check nhà cho khách.... Và còn nhiều mối lo khác nữa…
                    Chúng tôi – tập thể đội ngũ Nguonnhadat.com.vn đã cho ra đời trang web này. Với sứ mệnh giúp đỡ , chia sẻ để cộng đồng Môi giới chúng ta có được nguồn nhà phong phú, cập nhật nhanh, độ tin cậy cao với những tính năng trải nghiệm tốt nhất, để hàng ngày sẽ có hàng trăm giao dịch được tạo ra, giúp chúng ta bứt phá trong thu nhập.
                </p>
                <div style="max-width: 600px; margin: 0 auto;">
                    <p>
                        “Tin tôi đi! Nguonnhadat là sự lựa chọn nguồn nhà thông minh và tuyệt vời nhất
                        Nơi tạo dựng những ước mơ cho bạn.”
                    </p>
                    <p class="text-right">CEO nguonnhadat.com.vn Mr. Phạm Minh Trí</p>
                </div>
                <p>
                    <img src="<?php echo base_url('assets/sites/imgs/home-1.jpg'); ?>" alt="">
                </p>
                <p>
                    <img src="<?php echo base_url('assets/sites/imgs/home-2.jpg'); ?>" alt="">
                </p>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <?php require_once APPPATH.'/views/member/sidebar.php'; ?>
            </div>
        </div>
        <div class="row">
            <div class="jumbotron sale">
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="text-mau ">*Thành công bền vững, gia tăng thu nhập Chủ động công việc, không cầu không phế *</div>
                    <span class="text-mau2">Chỉ có duy nhất ở <b class="cam">Nguonnhadat</b>, hãy <b class="cam">đăng ký</b> ngay hôm nay.</span>
                    <span class="text-mau3 cam">Ưu đãi khủng với giá hỗ trợ từ CEO Nguonnhadat.com.vn</span>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <span class="bui1">Chỉ với</span>
                    <span class="bui2">199k</span>
                    <span class="bui3">Giá gốc <div class="giacu">799k</div></span>
                    <a href="#" class="btn btn-dk">Đăng ký dùng thử</a>
                </div>
            </div>
        </div>

        <!-- Modal Dùng Thử -->
        <div class="modal fade" id="register_form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">ĐĂNG KÝ DÙNG THỬ</h4>
                    </div>
                    <form method="post">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="">Họ và tên</label>
                                <input type="text" name="your_name" class="form-control" placeholder="Họ và tên..." required/>
                            </div>
                            <div class="form-group">
                                <label for="">Số điện thoại</label>
                                <input type="tel" name="your_phone" class="form-control" placeholder="Số điện thoại..." required/>
                            </div>
                            <div class="form-group">
                                <label for="">Lĩnh vực</label>
                                <select class="form-control" name="your_type" required>
                                    <option value="Môi giới nhà thổ cư">Môi giới nhà thổ cư</option>
                                    <option value="Môi giới cho thuê">Môi giới cho thuê</option>
                                    <option value="Môi giới nhà dự án">Môi giới nhà dự án</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                            <button type="submit" class="btn btn-primary">Đăng ký ngay</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modal-forget-user">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Quên mật khẩu</h4>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" role="form" class="form-forget">

                            <div class="form-group">
                                <label for="fullname">Địa chỉ email</label>
                                <input type="email" class="form-control email_address" name="email_address" placeholder="Địa chỉ email...">
                            </div>

                            <button type="button" class="btn btn-primary text-center btn-forget">Xác nhận</button>

                        </form>
                    </div>

                </div>
            </div>
        </div>
       
        <div class="modal fade" id="modal-register-user">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Đăng ký thành viên</h4>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" role="form" class="form-register">

                            <div class="form-group">
                                <label for="fullname">Họ và tên</label>
                                <input type="text" class="form-control fullname bd" name="fullname" placeholder="Họ và tên...">
                                <p class="fullname" style="color: red;"></p>
                            </div>
                            <div class="form-group">
                                <label for="email_address">Địa chỉ email</label>
                                <input type="text" class="form-control email_address bd" name="email_address" placeholder="Địa chỉ email...">
                                <p class="email_address" style="color: red;"></p>
                            </div>
                            <div class="form-group">
                                <label for="user_phone">Số điện thoại</label>
                                <input type="text" class="form-control user_phone bd" name="user_phone"  placeholder="Số điện thoại...">
                                <p class="user_phone" style="color: red;"></p>
                            </div>
                            <div class="form-group">
                                <label for="user_address">Địa chỉ</label>
                                <input type="text" class="form-control user_address bd" name="user_address" placeholder="Địa chỉ...">
                                <p class="user_address" style="color: red;"></p>
                            </div>
                            <hr/>
                            <div class="form-group ">
                                <label for="re_username">Tài khoản</label>
                                <input type="text" class="form-control username bd" name="username" placeholder="Tài khoản...">
                                <p class="username" style="color: red;"></p>
                            </div>
                            <div class="form-group">
                                <label for="pw1">Mật khẩu</label>
                                <input type="password" class="form-control password bd" name="password" placeholder="Mật khẩu...">
                                <p class="password" style="color: red;"></p>
                            </div>

                            <div class="form-group">
                                <label for="pw1">Nhập lại mật khẩu</label>
                                <input type="password" class="form-control confirm_password bd" name="confirm_password" placeholder="Nhập lại mật khẩu...">
                                <p class="confirm_password" style="color: red;"></p>
                            </div>

                            <button type="button" class="btn btn-primary text-center btn-register">Đăng ký</button>

                        </form>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end maincontet -->
<?php require_once APPPATH.'/views/member/footer.php'; ?>