<?php
require_once APPPATH.'/views/member/header.php';
if ($login):
?>
<div class="seach">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <h2 class="title"> <?php echo $page_title; ?></h2>
            </div>
        </div>
        <div class="jumbotron">
                <form method="get">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <div class="form-group">
                                <input type="text" name="keyword" class="form-control" value="<?php echo @$_GET['keyword']; ?>" placeholder="Nhập từ khóa tìm kiếm">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                            <div class="form-group">
                                <select class="form-control" name="province_id" id="province_id">
                                    <option value="0">Chọn Tỉnh / Thành phố</option>
                                    <?php
                                        if ($list_province):
                                            foreach ($list_province as $item):
                                                ?>
                                    <option value="<?php echo $item['matp']; ?>" <?php echo (isset($_GET['province_id']) && $_GET['province_id']==$item['matp'])?'selected':FALSE; ?>><?php echo $item['name']; ?></option>
                                    <?php
                                        endforeach; endif;
                                        ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                            <div class="form-group">
                                <select class="form-control" name="district_id" id="district_id">
                                    <option value="0">Chọn Quận / huyện</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary btn-seach"><i class="fa fa-search" aria-hidden="true"></i>Tìm Kiếm</button>
                                </div>
                        </div>
                    </div>
                    <small class="bd-show">Tìm kiếm nâng cao <i class="fa fa-caret-down" aria-hidden="true"></i></small>
                    <div class="row bd-hide">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <select class="form-control" id="category_id" name="category_id">
                                        <option value="0">Chọn danh mục</option>
                                        <?php
                                        if ($category_parent):
                                            foreach ($category_parent as $item):
                                                ?>
                                                <option value="<?php echo $item['cate_id']; ?>" <?php echo (isset($_GET['category_id']) && $_GET['category_id']==$item['cate_id'])?'selected':FALSE; ?>><?php echo $item['cate_name']; ?></option>
                                                <?php
                                                $category_child = $this->get_data->get_category_child($item['cate_id']);
                                                if ($category_child)
                                                {
                                                    foreach ($category_child as $child)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $child['cate_id'] ?>" <?php echo (isset($_GET['category_id']) && $_GET['category_id']==$child['cate_id'])?'selected':FALSE; ?>>- <?php echo $child['cate_name']; ?></option>
                                                        <?php
                                                    }
                                                }
                                            endforeach;
                                        endif;
                                        ?>
                                    </select>
                                </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                             <div class="form-group">
                                    <select class="form-control" name="area">
                                        <option value="0">Chọn diện tích</option>
                                        <option value="0-30" <?php echo (isset($_GET['area']) && $_GET['area']=='0-30')?'selected':FALSE; ?>>Dưới 30 m2</option>
                                        <option value="30-50" <?php echo (isset($_GET['area']) && $_GET['area']=='30-50')?'selected':FALSE; ?>>30&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;50 m2</option>
                                        <option value="50-70" <?php echo (isset($_GET['area']) && $_GET['area']=='50-70')?'selected':FALSE; ?>>50&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;70 m2</option>
                                        <option value="70-100" <?php echo (isset($_GET['area']) && $_GET['area']=='70-100')?'selected':FALSE; ?>>70&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;100 m2</option>
                                        <option value="100-150" <?php echo (isset($_GET['area']) && $_GET['area']=='100-150')?'selected':FALSE; ?>>100&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;150 m2</option>
                                        <option value="150-200" <?php echo (isset($_GET['area']) && $_GET['area']=='150-200')?'selected':FALSE; ?>>150&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;200 m2</option>
                                        <option value="200-250" <?php echo (isset($_GET['area']) && $_GET['area']=='200-250')?'selected':FALSE; ?>>200&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;250 m2</option>
                                        <option value="250-300" <?php echo (isset($_GET['area']) && $_GET['area']=='250-300')?'selected':FALSE; ?>>250&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;300 m2</option>
                                        <option value="300-350" <?php echo (isset($_GET['area']) && $_GET['area']=='300-350')?'selected':FALSE; ?>>300&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;350 m2</option>
                                        <option value="350-400" <?php echo (isset($_GET['area']) && $_GET['area']=='350-400')?'selected':FALSE; ?>>350&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;400 m2</option>
                                        <option value="400-600" <?php echo (isset($_GET['area']) && $_GET['area']=='400-600')?'selected':FALSE; ?>>400&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;600 m2</option>
                                        <option value="600-800" <?php echo (isset($_GET['area']) && $_GET['area']=='600-800')?'selected':FALSE; ?>>600&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;800 m2</option>
                                        <option value="800-1000" <?php echo (isset($_GET['area']) && $_GET['area']=='800-1000')?'selected':FALSE; ?>>800&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;1000 m2</option>
                                        <option value="1000-0" <?php echo (isset($_GET['area']) && $_GET['area']=='1000-0')?'selected':FALSE; ?>>Trên 1000 m2</option>
                                    </select>
                                </div>
                               
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                            <div class="form-group">
                                    <select class="form-control" name="price">
                                        <option value="0">Chọn mức giá</option>
                                        <option value="0-1" <?php echo (isset($_GET['price']) && $_GET['price']=='0-1')?'selected':FALSE; ?>>&lt;= 1 triệu/tháng</option>
                                        <option value="1-3" <?php echo (isset($_GET['price']) && $_GET['price']=='1-3')?'selected':FALSE; ?>>1 - 3 triệu/tháng</option>
                                        <option value="3-5" <?php echo (isset($_GET['price']) && $_GET['price']=='3-5')?'selected':FALSE; ?>>3 - 5 triệu/tháng</option>
                                        <option value="5-10" <?php echo (isset($_GET['price']) && $_GET['price']=='5-10')?'selected':FALSE; ?>>5 - 10 triệu/tháng</option>
                                        <option value="10-20" <?php echo (isset($_GET['price']) && $_GET['price']=='10-20')?'selected':FALSE; ?>>10 - 20 triệu/tháng</option>
                                        <option value="20-50" <?php echo (isset($_GET['price']) && $_GET['price']=='20-50')?'selected':FALSE; ?>>20 - 50 triệu/tháng</option>
                                        <option value="50-0" <?php echo (isset($_GET['price']) && $_GET['price']=='50-0')?'selected':FALSE; ?>>&gt; 50 triệu/tháng</option>
                                    </select>
                                </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                               
                                <div class="form-group cot">
                                        <label for="" class="title-tim">Ngày Bắt Đầu</label>
                                        <input class="form-control" name="date_end" type="date" value="" id="example-datetime-local-input">
                                </div>
                                <div class="form-group hai">
                                    <label for="" class="title-tim">Ngày Kết Thúc</label>
                                        <input class="form-control" name="date_start" type="date" value="" id="example-datetime-local-input">
                                </div>
                        </div>
                       
                    </div>
                    
                </form>
            </div>
            <!-- end jumbotron -->
        </div>
    </div>
    <!-- end tim kiếm -->

    <div class="main-content">
        <div class="container">
            <br>

            <?php if ($login['user_type']>=0 && date('Y-m-d')>=$login['start_date'] && date('Y-m-d')<=$login['end_date']): ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table id="mytable" class="table table-bordred ">
                            <thead>
                                <th width="5%">STT</th>
                                <th>Tiêu đề</th>
                                <th width="10%">Ngày đăng</th>
                                <th width="10%">Giá</th>
                                <th width="10%">Điện thoại</th>
                                <th width="10%">Loại tin</th>
                                <th width="7%"></th>
                            </thead>
                            <tbody>
                                <?php
                                if ($list_post):
                                    $count = 0;
                                    foreach ($list_post as $item):
                                        $count++;
                                        $contact = $item['contact'];
                                        preg_match('/([0-9]{10,11})/', $contact, $maches);
                                        $phone = $maches[0];
                                        $cate_arr = json_decode($item['cate_id'], true);
                                        $cate_name = $this->get_data->get_category($cate_arr[0]);
                                        ?>
                                        <tr>
                                            <td><?php echo $count; ?></td>

                                            <td>
                                                <p><p><a href="#popup_<?php echo $item['post_id']; ?>" data-post-id="<?php echo $item['post_id']; ?>" class="post-title <?php echo ($this->get_data->is_post_read($item['post_id']))?'read':FALSE; ?> post-<?php echo $item['post_id']; ?>" data-toggle="modal"><b><?php echo $item['post_title']; ?></b></a></p>
                                                <div class="mota">
                                                    <b>Quận Huyện:</b> <?php echo ($this->get_data->get_district($item['district_id']))?$this->get_data->get_district($item['district_id']):'Không xác định'; ?> <b>Tỉnh/ Thành Phố:</b> <?php echo ($this->get_data->get_province($item['province_id']))?$this->get_data->get_province($item['province_id']):'Không xác định'; ?>
                                                </div>
                                            </td>
                                            <td><?php echo date('d/m/Y', $item['timestamp']); ?></td>
                                            <td><?php echo ($item['price'])?($this->get_data->get_price_string($item['price'])).$item['unit']:'Thỏa thuận'; ?></td>
                                            <td><?php echo $phone; ?></td>
                                            <td>Tin mới</td>
                                            <td>
                                                <a href="#" id="" data-post-id="<?php echo $item['post_id']; ?>" class="ico save_post"><img src="<?php echo base_url('assets/sites/imgs/luu.png'); ?>" alt=""></a>
                                                <a href="#popup_<?php echo $item['post_id']; ?>" data-toggle="modal" data-post-id="<?php echo $item['post_id']; ?>" class="ico post-title"><img src="<?php echo base_url('assets/sites/imgs/do.png'); ?>" alt=""></a>
                                                <div class="modal fade popup" id="popup_<?php echo $item['post_id']; ?>" tabindex="-12" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
                                                                <h4 class="modal-title custom_align" id="Heading">Thông tin chi tiết</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                                                        <h3 class="title"><?php echo $item['post_title']; ?></h3>
                                                                        <p>Nội dung tin đăng:</p>
                                                                        <div>
                                                                            <?php $content = preg_replace('/&nbsp;/', '', html_entity_decode($item['post_content']));
                                                                                  echo $content;
                                                                            ?>
                                                                        </div>
                                                                        <div class="slide2">
                                                                            <div class="owl-carousel owl-theme slide-bds2">
                                                                                <div class="item">
                                                                                    <img src="<?php echo $item['thumbnail']; ?>" alt="">
                                                                                </div>
                                                                                <?php if ($this->get_data->get_post_images($item['post_id'])):
                                                                                            foreach ($this->get_data->get_post_images($item['post_id']) as $image):
                                                                                    ?>
                                                                                                <div class="item">
                                                                                                    <img src="<?php echo $image['image_url']; ?>" alt="">
                                                                                                </div>
                                                                                <?php endforeach; endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                                                        <div class="bui-pop">
                                                                            <div class="s-title">Giá tiền:</div> <?php echo ($item['price'])?($this->get_data->get_price_string($item['price'])).$item['unit']:'Thỏa thuận'; ?><br>
                                                                            <div class="s-title">Liên hệ: </div> <?php echo $phone; ?> <br>
                                                                            <div class="s-title">Ngày đăng: </div> <?php echo date('d/m/Y', $item['timestamp']); ?> <br>
                                                                            <div class="s-title">Loại tin: </div> <?php echo ($cate_name)?$cate_name:'Không xác định'; ?> <br>
                                                                            <div class="s-title">Tỉnh / TP: </div> <?php echo ($this->get_data->get_province($item['province_id']))?$this->get_data->get_province($item['province_id']):'Không xác định'; ?><br>
                                                                            <div class="s-title">Quận / Huyện: </div> <?php echo ($this->get_data->get_district($item['district_id']))?$this->get_data->get_district($item['district_id']):'Không xác định'; ?><br>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer ">
                                                                <a href="#" id="" data-post-id="<?php echo $item['post_id']; ?>" class="ico save_post"><img src="<?php echo base_url('assets/sites/imgs/luu.png'); ?>" alt=""></a>
                                                            </div>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; endif; ?>
                                </tbody>
                            </table>
                            <div class="clearfix"></div>
                            <center>
                            <div class="number-1">
                                <?php echo $pagination; ?>
                            </div>

                        </center>

                    </div>
                </div>
            </div>

            <?php else: ?>
                <div class="container">
                    <div class="alert alert-info text-center">
                        Bạn không có quyền truy cập vào khu vực này hoặc bạn đã hết thời gian sử dụng. Vui lòng liên hệ để gia hạn
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php else: ?>
    <div class="container">
        <div class="alert alert-info text-center">
            Vui lòng đăng nhập để thực hiện chức năng này! Đăng nhập <a href="<?php echo base_url(); ?>"><b>tại đây</b></a>
        </div>
    </div>

<?php endif; ?>
<?php require_once APPPATH.'/views/member/footer.php'; ?>