<?php
	public function regex_price($price)
	{
		$price = explode(" ", $price);
		echo "<pre>";
		print_r($price);
		echo "</pre>"
	}

	regex_price("22 triệu/tháng");
?>