<?php
class Crawl_data extends CI_Controller
{
	protected $_data;
	public function __construct()
	{
	    set_time_limit(0);
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Mpost');
		$this->load->model('Mcategory');
		$this->load->library('Get_data');
		$this->load->library('Crawler');
		$this->load->library('Globals');
	}
	public function index()
	{
        print_r($this->get_data->get_cate_by_crawl('muaban'));
	}
	public function get_price($price)
	{

		if (preg_match('/triệu/',$price)) {
			$explode_price = (explode(" ", $price));
			$new_price 	   = $explode_price['0'] * 10000000;
			return $new_price;
		}
		if (preg_match('/tỷ/',$price)) {
			$explode_price = (explode(" ", $price));
			$new_price	   = $explode_price['0'] * 1000000000;
			return $new_price;
		}
		else{
			return $price;
		}
		
    }
    
    // phuc kenhbds
    public function convert_price_kenhbds($price){
        
        $price = preg_match('/[0-9\.]+/',$price,$matches);
        return $matches[0];

    }
	public function crawler_batdongsan()
	{


        $cate_arr = $this->get_data->get_cate_by_crawl('batdongsan');

        if ($cate_arr)
        {
            foreach ($cate_arr as $link_cate=>$cate_id)
            {
                if ($cate_arr[$link_cate])
                {

                    $pages = $this->crawler->get_list_url($link_cate, '.background-pager-right-controls', 'https://batdongsan.com.vn');

                    $max_page = end($pages);

                    $max_page = str_replace($link_cate, '', $max_page);

                    $max_page = str_replace('/p', '', $max_page);

                    if ($max_page>0)
                    {
                        for ($i=$max_page; $i>=1; $i--)
                        {
                            if ($i>1)
                            {
                                $a = $this->crawler->get_list_url($link_cate.'/p'.$i,'.p-title','https://batdongsan.com.vn');
                            }
                            else
                            {
                                $a = $this->crawler->get_list_url($link_cate,'.p-title','https://batdongsan.com.vn');
                            }

                            $array = array(
                                'title' => '{"element":"div.pm-title","count":0}',
                                'area' => '{"element":"span.diadiem-title","count":0}',
                                'price' => '{"element":"span.gia-title strong","count":0}',
                                'square' => '{"element":"span.gia-title strong","count":1}',
                                'desc'   => '{"element":"div.pm-desc","count":0}',
                                'galerry' => '{"element":"ul#thumbs li img","count":0,"loop":"true"}',
                                'map_lat'     =>  '{"element":"input#hdLat","count":0,"convert":"true"}',
                                'map_long'     =>  '{"element":"input#hdLong","count":0,"convert":"true"}',
                                'table_bds'     =>  '{"element":"div.table-detail ","count":0,"loop":".row","convert":"true"}',
                                'table_bds2'     =>  '{"element":"div.table-detail ","count":1,"loop":".right-content","convert":"true"}',
                                'date_create'     =>  '{"element":"div.prd-more-info div","count":3,"convert":"true"}',
                            );

                            foreach ($a as $arr)
                            {

                                $value = $this->crawler->get_dom_single_page($arr);

                                $result_arr = $this->crawler->get_data($value,$array);

                                $post_title = $result_arr['title'];

                                $post_slug = $this->globals->change_to_slug($result_arr['title']);

                                $post_content = $result_arr['desc'];

                                $cate_id = json_encode(array($cate_arr[$link_cate]));

                                $timestamp = strtotime(date('Y-m-d H:i:s'));

                                if (preg_match('/cho-thue/', $link_cate))
                                {
                                    $unit = '/tháng';
                                }
                                else
                                {
                                    $unit = '';
                                }

                                preg_match('/[0-9]+-[0-9]+-[0-9]+/', $result_arr['date_create'], $maches);
                                if ($maches)
                                {
                                    $date = $maches[0];
                                    $timestamp = strtotime($date);
                                }

                                $area_arr = explode('-', $result_arr['area']);

                                $province_name = $area_arr[count($area_arr)-1];

                                $province_id = $this->get_data->get_province_id_by_name($province_name);

                                $district_name = $area_arr[count($area_arr)-2];

                                $district_id = $this->get_data->get_district_id_by_name($district_name);

                                $feadtured   		=  0;
                                $for_vip_user 		=  0;
                                $active       		=  1;
                                $crawler_type 		=  1;

                                $price = $this->get_price($result_arr['price']);

                                $contact = '';

                                if (!empty($result_arr['table_bds2']))
                                {
                                    preg_match('/([0-9]{10,11})/', implode(' ', $result_arr['table_bds2']), $maches);

                                    if ($maches)
                                    {
                                        $contact = $maches[0];
                                    }

                                    else
                                    {
                                        $contact = '';
                                    }
                                }
                                $area = '';

                                if (!empty($result_arr['square']))
                                {
                                    preg_match('/([0-9]{1,})/', $result_arr['square'], $maches);

                                    if ($maches)
                                    {
                                        $area = $maches[0];
                                    }

                                    else
                                    {
                                        $area = '';
                                    }
                                }

                                $check_post_title 	= $this->Mpost->check_post_title_exists($post_title); // return number rows


                                $data_insert  = array(
                                    'post_title'  		=> $post_title,
                                    'post_slug'  		=> $post_slug,
                                    'post_content' 		=> $this->globals->get_the_content($post_content),
                                    'cate_id'			=> $cate_id,
                                    'timestamp'			=> $timestamp,
                                    'province_id'  		=> $province_id,
                                    'district_id' 		=> $district_id,
                                    'price'				=> $price,
                                    'contact'			=> trim($contact),
                                    'feadtured_post'   	=> $feadtured,
                                    'for_vip_user' 		=> $for_vip_user,
                                    'active'			=> $active,
                                    'crawler_type'		=> $crawler_type,
                                    'unit' => $unit,
                                    'area' => $area

                                );
                                if ($check_post_title == 0) {
                                    $data_insert = $this->Mpost->insert($data_insert);
                                }

                            }

                        }
                    }

                }

            }
            die();
        }

	}

	public function crawler_muaban()
	{
		$cate_arr = $this->get_data->get_cate_by_crawl('muaban');

        if ($cate_arr) {
            foreach ($cate_arr as $link_cate => $cate_id) {
                if ($cate_arr[$link_cate]) {
                    for ($i=200; $i>=1; $i--)
                    {
                        $a = $this->crawler->get_list_url($link_cate.'?cp='.$i,'.mbn-box-list-content ');

                        $a = array_unique($a);

                        $array = array(
                            'title' => '{"element":"div.cl-title h1","count":0}',
                            'time_create' => '{"element":"span.detail-clock","count":0}',
                            'desc' => '{"element":"div.ct-body","count":0}',
                            'price' => '{"element":"p.price","count":0}',
                            // 'square' => '{"element":".pd-price span","count":1}',
                            'address'   => '{"element":"span.detail-location","count":0}',
                            'galerry' => '{"element":"div.ct-image .item img","count":0,"loop_muaban":"true"}',
                            'table_bds'     =>  '{"element":".ct-tech ul ","count":0,"loop":"li.tect-item","convert":"true"}',
                            'contact_name'     =>  '{"element":".col-xs-9","count":1}',
                            'contact_add'     =>  '{"element":".col-xs-9","count":2}',
                            'contact_phone'     =>  '{"element":".contactmobile-desktop","count":3}',
                            // 'map_lat'     =>  '{"element":"input#hddLatitude","count":0,"convert":"true"}',
                            // 'map_long'     =>  '{"element":"input#hddLongtitude","count":0,"convert":"true"}',
                            // // 'table_bds2'     =>  '{"element":"div.table-detail ","count":1,"loop":".right-content","convert":"true"}',
                        );

                        foreach ($a as $arr)
                        {

                            $value = $this->crawler->get_dom_single_page($arr);
                            $result_arr = $this->crawler->get_data($value,$array);


                            $post_title = $result_arr['title'];

                            $post_slug = $this->globals->change_to_slug($result_arr['title']);

                            $post_content = $result_arr['desc'];

                            $cate_id = json_encode(array((string)$cate_arr[$link_cate]));

                            $timestamp = strtotime(date('Y-m-d H:i:s'));

                            if ($result_arr['time_create'])
                            {
                                $date_create = date_create_from_format('d/m/Y', $result_arr['time_create']);
                                if ($date_create)
                                {
                                    $timestamp = strtotime($date_create->format('Y-m-d'));
                                }

                            }

                            $area_arr = explode('-', $result_arr['address']);

                            $province_name = $area_arr[count($area_arr)-1];

                            if (preg_match('/cho-thue/', $link_cate))
                            {
                                $unit = '/tháng';
                            }
                            else
                            {
                                $unit = '';
                            }

                            if (trim($province_name)=='TP.HCM')
                            {
                                $province_name = 'Hồ Chí Minh';
                            }

                            $province_id = $this->get_data->get_province_id_by_name($province_name);

                            $district_name = $area_arr[count($area_arr)-2];

                            $district_id = $this->get_data->get_district_id_by_name($district_name);

                            $feadtured   		=  0;
                            $for_vip_user 		=  0;
                            $active       		=  1;
                            $crawler_type 		=  1;

                            $price = 0;

                            if ($result_arr['price'])
                            {
                                preg_match('/[0-9\.]+/', $result_arr['price'], $price_arr);
                                $price = str_replace('.', '', $price_arr[0]);

                                $price = $this->get_price(trim($price));

                            }


                            $contact = '';

                            if (is_numeric($result_arr['contact_name']))
                            {
                                $contact = $result_arr['contact_name'];
                            }

                            if (is_numeric($result_arr['contact_add']))
                            {
                                $contact = $result_arr['contact_add'];
                            }

                            if (is_numeric($result_arr['contact_phone']))
                            {
                                $contact = $result_arr['contact_phone'];
                            }

                            $area = '';

                            $check_post_title 	= $this->Mpost->check_post_title_exists($post_title);

                            $data_insert  = array(
                                'post_title'  		=> $post_title,
                                'post_slug'  		=> $post_slug,
                                'post_content' 		=> $this->globals->get_the_content($post_content),
                                'cate_id'			=> $cate_id,
                                'timestamp'			=> $timestamp,
                                'province_id'  		=> $province_id,
                                'district_id' 		=> $district_id,
                                'price'				=> $price,
                                'contact'			=> trim($contact),
                                'feadtured_post'   	=> $feadtured,
                                'for_vip_user' 		=> $for_vip_user,
                                'active'			=> $active,
                                'crawler_type'		=> $crawler_type,
                                'unit' => $unit,
                                'area' => $area

                            );
                            if ($check_post_title == 0) {
                                $data_insert = $this->Mpost->insert($data_insert);
                            }

                        }
                    }
                }
            }
        }


	}

    public function crawler_alonhadat()
    {

        $cate_arr = $this->get_data->get_cate_by_crawl('alonhadat');

        if ($cate_arr)
        {
            foreach ($cate_arr as $link_cate => $cate_id) {
                if ($cate_arr[$link_cate])
                {
                    $pages = $this->crawler->get_list_url(str_replace('.html', '', $link_cate).'/trang--100000.html', '.page', 'https://alonhadat.com.vn');

                    $max_page = end($pages);

                    $max_page = str_replace(str_replace('.html', '', $link_cate), '', $max_page);

                    $max_page = str_replace('/trang--', '', $max_page);

                    $max_page = str_replace('.html', '', $max_page);

                    for ($i=$max_page; $i>=1; $i--)
                    {
                        $a = $this->crawler->get_list_url(str_replace('.html', '', $link_cate).'/trang--'.$i.'.html', '.ct_title', 'https://alonhadat.com.vn');


                        $array = array(
                            'title' => '{"element":"div.title h1","count":0}',
                            'time_create' => '{"element":"span.date","count":0}',
                            'desc' => '{"element":"div.detail","count":0}',
                            'price' => '{"element":"span.price span.value","count":0}',
                            'square' => '{"element":"span.square span.value","count":0}',
                            'address' => '{"element":"div.address span.value","count":0}',
                            'galerry' => '{"element":"div.image-list span img","count":0,"loop":"true"}',
                            'table_bds' => '{"element":"tr td","count":0,"loop_alonhadat":".infor"}',
                            'contact' => '{"element":".contact-info .fone a", "count":0}'
                        );
                        foreach ($a as $arr) {
                            $value = $this->crawler->get_dom_single_page($arr);
                            $result_arr = $this->crawler->get_data($value, $array, 'https://alonhadat.com.vn');

                            $post_title = $result_arr['title'];

                            $post_slug = $this->globals->change_to_slug($result_arr['title']);

                            $post_content = $result_arr['desc'];

                            $cate_id = json_encode(array((string)$cate_arr[$link_cate]));

                            $timestamp = strtotime(date('Y-m-d H:i:s'));

                            preg_match('/[0-9]+\/[0-9]+\/[0-9]+/', $result_arr['time_create'], $maches);
                            if ($maches)
                            {
                                $date = $maches[0];

                                $date_object = date_create_from_format('d/m/Y', $date);

                                if ($date_object)
                                {
                                    $timestamp = strtotime($date_object->format('Y-m-d'));

                                }

                            }

                            $area_arr = explode(',', $result_arr['address']);

                            $province_name = $area_arr[count($area_arr)-1];

                            if (trim($province_name)=='TP.HCM')
                            {
                                $province_name = 'Hồ Chí Minh';
                            }

                            $province_id = $this->get_data->get_province_id_by_name($province_name);

                            $district_name = $area_arr[count($area_arr)-2];

                            $district_id = $this->get_data->get_district_id_by_name($district_name);

                            $feadtured   		=  0;
                            $for_vip_user 		=  0;
                            $active       		=  1;
                            $crawler_type 		=  1;

                            $price = 0;

                            if ($result_arr['price'])
                            {
                                $price = $this->get_price(trim($result_arr['price']));
                            }

                            $contact = '';

                            if ($result_arr['contact'])
                            {
                                $contact = str_replace('.', '', $result_arr['contact']);
                            }

                            $area = '';

                            if ($result_arr['square'])
                            {
                                preg_match('/([0-9]{1,})/', $result_arr['square'], $maches);

                                if ($maches)
                                {
                                    $area = $maches[0];
                                }

                                else
                                {
                                    $area = '';
                                }
                            }

                            if (preg_match('/cho-thue/', $link_cate))
                            {
                                $unit = '/tháng';
                            }
                            else
                            {
                                $unit = '';
                            }

                            $check_post_title 	= $this->Mpost->check_post_title_exists($post_title);

                            $data_insert  = array(
                                'post_title'  		=> $post_title,
                                'post_slug'  		=> $post_slug,
                                'post_content' 		=> $this->globals->get_the_content($post_content),
                                'cate_id'			=> $cate_id,
                                'timestamp'			=> $timestamp,
                                'province_id'  		=> $province_id,
                                'district_id' 		=> $district_id,
                                'price'				=> $price,
                                'contact'			=> trim($contact),
                                'feadtured_post'   	=> $feadtured,
                                'for_vip_user' 		=> $for_vip_user,
                                'active'			=> $active,
                                'crawler_type'		=> $crawler_type,
                                'unit' => $unit,
                                'area' => $area,
                                'address' => $result_arr['address']

                            );
                            if ($check_post_title == 0) {
                                $data_insert = $this->Mpost->insert($data_insert);
                            }

                        }

                    }

                }
            }
        }

    }

    public function crawler_dothi()
    {

        $cate_arr = $this->get_data->get_cate_by_crawl('dothi');

        if ($cate_arr)
        {
            foreach ($cate_arr as $link_cate => $cate_id) {
                if ($cate_arr[$link_cate])
                {

                    $pages = $this->crawler->get_list_url(str_replace('.htm', '', $link_cate).'/p10000.htm', '.pager_controls', 'https://dothi.net');

                    $max_page = end($pages);

                    $max_page = str_replace(str_replace('.htm', '', $link_cate), '', $max_page);

                    $max_page = str_replace('/p', '', $max_page);

                    $max_page = str_replace('.htm', '', $max_page);

                    for ($i=$max_page; $i>=1; $i++)
                    {
                        $a = $this->crawler->get_list_url(str_replace('.htm', '', $link_cate).'/p'.$i.'.htm','.for-user ul li','https://dothi.net');

                        foreach ($a as $key => $value) {

                            if (($key = array_search('https://dothi.net', $a)) !== false) {
                                unset($a[$key]);
                            }

                        }

                        $a = array_unique($a);

                        $array = array(
                            'title' => '{"element":"div.product-detail h1","count":0}',
                            'desc' => '{"element":"div.pd-desc-content","count":0}',
                            'price' => '{"element":"span.spanprice","count":0}',
                            'square' => '{"element":".pd-price span","count":1}',
                            'address'   => '{"element":"div.pd-location","count":0}',
                            'galerry' => '{"element":"ul#myGallery li img","count":0,"loop":"true"}',
                            'table_bds'     =>  '{"element":" tr td","count":0,"loop_alonhadat":".pd-dacdiem"}',
                            'table_bds2'     =>  '{"element":" tr td","count":0,"loop_alonhadat":".pd-contact"}',
                            'map_lat'     =>  '{"element":"input#hddLatitude","count":0,"convert":"true"}',
                            'map_long'     =>  '{"element":"input#hddLongtitude","count":0,"convert":"true"}',
                        );
                        foreach ($a as $arr) {

                            $value = $this->crawler->get_dom_single_page($arr);
                            $result_arr = $this->crawler->get_data($value,$array);


                         $post_title = $result_arr['title'];

                         $post_slug = $this->globals->change_to_slug($result_arr['title']);

                         $post_content = $result_arr['desc'];

                         $cate_id = json_encode(array((string)$cate_arr[$link_cate]));

                         $timestamp = strtotime(date('Y-m-d H:i:s'));

                         $area_arr = explode('-', $result_arr['address']);

                         $province_name = $area_arr[count($area_arr)-1];

                         if (trim($province_name)=='TP.HCM')
                         {
                             $province_name = 'Hồ Chí Minh';
                         }

                         $province_id = $this->get_data->get_province_id_by_name(trim($province_name));

                         $district_name = $area_arr[count($area_arr)-2];

                         $district_id = $this->get_data->get_district_id_by_name(trim($district_name));

                         $feadtured   		=  0;
                         $for_vip_user 		=  0;
                         $active       		=  1;
                         $crawler_type 		=  1;

                         $price = 0;

                         if ($result_arr['price'])
                         {
                             $price = $this->get_price(trim(mb_strtolower($result_arr['price'])));
                         }

                         $contact = '';

                         if ($result_arr['table_bds2']['Di động'])
                         {
                             $contact = str_replace('.', '', trim($result_arr['table_bds2']['Di động']));
                         }

                         $area = '';

                            if (preg_match('/cho-thue/', $link_cate))
                            {
                                $unit = '/tháng';
                            }
                            else
                            {
                                $unit = '';
                            }

                            if ($result_arr['table_bds']['Ngày đăng tin'])
                            {
                                $date = trim($result_arr['table_bds']['Ngày đăng tin']);

                                $date = strip_tags($date);

                                $date = trim($date);

                                $date_object = date_create_from_format('d/m/Y', $date);

                                if ($date_object)
                                {
                                    $timestamp = strtotime($date_object->format('Y-m-d'));
                                    echo $timestamp;
                                }

                            }

                         $check_post_title 	= $this->Mpost->check_post_title_exists($post_title);

                         $data_insert  = array(
                             'post_title'  		=> $post_title,
                             'post_slug'  		=> $post_slug,
                             'post_content' 	=> $this->globals->get_the_content($post_content),
                             'cate_id'			=> $cate_id,
                             'timestamp'			=> $timestamp,
                             'province_id'  		=> $province_id,
                             'district_id' 		=> $district_id,
                             'price'				=> $price,
                             'contact'			=> strip_tags(trim($contact)),
                             'feadtured_post'   	=> $feadtured,
                             'for_vip_user' 		=> $for_vip_user,
                             'active'			=> $active,
                             'crawler_type'		=> $crawler_type,
                             'unit' => $unit,
                             'area' => $area

                         );
                         if ($check_post_title == 0) {
                             $data_insert = $this->Mpost->insert($data_insert);
                         }

                        }
                    }
                }
            }
        }
    }

    public function crawler_123nhaviet()
    {


        $cate_arr = $this->get_data->get_cate_by_crawl('123nhadatviet');

        print_r($cate_arr);
        
        // if ($cate_arr)
        // {
        //     foreach ($cate_arr as $link_cate=>$cate_id)
        //     {
        //         if ($cate_arr[$link_cate])
        //         {

        //             // $pages = $this->crawler->get_list_url($link_cate, '.background-pager-right-controls', 'https://batdongsan.com.vn');

        //             $max_page = end($pages);

        //             $max_page = str_replace($link_cate, '', $max_page);

        //             $max_page = str_replace('/p', '', $max_page);
        //             $max_page = 15;

        //             if ($max_page>0)
        //             {
        //                 for ($i=$max_page; $i>=1; $i--)
        //                 {
        //                     if ($i>1)
        //                     {
        //                         // $a = $this->crawler->get_list_url($link_cate.'/p'.$i,'.p-title','https://batdongsan.com.vn');

        //                         $a = $this->crawler->get_list_url($link_cate.'/trang--'.$i.'.html','.ct_title','http://123nhadatviet.com');
        //                     }
        //                     else
        //                     {
        //                         // $a = $this->crawler->get_list_url($link_cate,'.p-title','https://batdongsan.com.vn');
        //                     }

        //                     $array = array(
        //                     'title' => '{"element":"div.title","count":0}',
        //                     'area' => '{"element":"div.address .value","count":0,"convert":"true"}',
        //                     // 'price' => '{"element":"span.price","count":0}',
        //                     // // 'square' => '{"element":"label.lb-pri-dt strong","count":1}',
        //                     'desc'   => '{"element":"div.detail","count":0}',
        //                     'galerry' => '{"element":".image-list ul li img","count":0,"loop":"true"}',
        //                     // // 'map_lat'     =>  '{"element":"input#txtLAT","count":0,"map_":"value"}',
        //                     // // 'map_long'     =>  '{"element":"input#txtLON","count":0,"map_":"value"}',
        //                     'table_bds'     =>  '{"element":".infor tr td","count":0,"loop_i_nha_dat":"true","convert":"true"}',

        //                     'contact_name'     =>  '{"element":".contact-info .content .name","count":0}',
        //                     'contact_add'     =>  '{"element":".contact-info .content .fone a","count":0}',
        //                     // // 'contact_phone'     =>  '{"element":"a#viewmobinumber","count":0}',
        //                     // // // 'table_bds2'     =>  '{"element":"div.table-detail ","count":1,"loop":".right-content","convert":"true"}',
        //                     // 'date_create'     =>  '{"element":"span#MainContent_ctlDetailBox_lblDateCreated","count":0}',
        //                     );

        //                     foreach ($a as $arr) {
        //                         $value =  $this->crawler->get_dom_single_page($arr);
        //                         $result_arr =  $this->crawler->get_data($value,$array,"http://123nhadatviet.com");
        //                         // echo $arr."<br>";
        //                         $post_title = $result_arr['title'];
        //                         $post_slug = $this->globals->change_to_slug($result_arr['title']);
        //                         $post_content = $result_arr['desc'];
        //                         $timestamp = date('Y-m-d H:i:s');
        //                         $post_thumbnai = $result_arr['galerry'][0];
        //                         $cate_id = json_encode(array($cate_arr[$link_cate]));
        //                         $area_arr = explode('-', $result_arr['area']);

        //                         $province_name = $area_arr[count($area_arr)-1];

        //                         $province_id = $this->get_data->get_province_id_by_name($province_name);

        //                         $district_name = $area_arr[count($area_arr)-2];

        //                         $district_id = $this->get_data->get_district_id_by_name($district_name);

        //                         $feadtured          =  0;
        //                         $for_vip_user       =  0;
        //                         $active             =  1;
        //                         $crawler_type       =  1;
        //                         $index = 0;
        //                         foreach ($result_arr['table_bds'] as $key => $value) {
                                   
        //                             $newkey = $this->globals->change_to_slug($key);
        //                             $result_arr['table_bds'][$index] = $result_arr['table_bds'][$key];
        //                             unset($result_arr['table_bds'][$key]);
        //                             $index++;
        //                         }
        //                         $price = $result_arr['table_bds'][17];
        //                         $price = strval($price);
        //                         // echo $price."<br>";
        //                         // $i1 = strpos($price, '</');
        //                         // echo $i1."<br>";

        //                         // if($i1)
        //                         // {
        //                         //     $abc = substr($price, 30,$i1-30);
        //                         //     echo $abc."<br>";
        //                         // }
        //                         preg_match_all("/<td colspan='3' class='price'>(.*?)<\/td>/", $price, $matches);
        //                         $price = $matches[1][0];
        //                         //echo $price;
        //                         if ($ity = strpos($price, 'tỷ') !== false) 
        //                         {
                                
        //                             // $ty = substr($price, 0,$ity+3);
        //                             preg_match_all("/(.*?) tỷ/", $price, $matchesTy);
                                    
        //                             $ty = $matchesTy[1][0];
        //                             echo $ty."<br>";
        //                             if ($idot = strpos($ty,',') !== false)
        //                             {
        //                                 $trieu = substr($ty,$ity+1);
                                      

        //                                 if($trieu/100<1)
        //                                 {
                                            
        //                                     if($trieu/10<1)
        //                                     {
        //                                         $trieu = $trieu*100;
        //                                     }
        //                                     else
        //                                         $trieu = $trieu*10;
        //                                 }
        //                                 echo $trieu."<br>";
        //                                 $ty = substr($ty, 0,$ity);
                                        
        //                                 // echo $ty."-".$trieu;
        //                                 $price = $ty*(1000000000)+$trieu*(1000000);
        //                                 echo $price;
        //                             }
        //                             else
        //                             {
        //                                 $price = $ty*(1000000000);
        //                             }
                                    
                                    
                                   
        //                         }
        //                         else if ($itrieu = strpos($price, 'triệu') !== false) 
        //                         {
                                
        //                             // $ty = substr($price, 0,$ity+3);
        //                             preg_match_all("/(.*?) tỷ/", $price, $matchesTy);
                                    
        //                             $ty = $matchesTy[1][0];
        //                             echo $ty."<br>";
        //                             if ($idot = strpos($ty,',') !== false)
        //                             {
        //                                 $trieu = substr($ty,$ity+1);
                                      

        //                                 if($trieu/100<1)
        //                                 {
                                            
        //                                     if($trieu/10<1)
        //                                     {
        //                                         $trieu = $trieu*100;
        //                                     }
        //                                     else
        //                                         $trieu = $trieu*10;
        //                                 }
        //                                 echo $trieu."<br>";
        //                                 $ty = substr($ty, 0,$ity);
                                        
        //                                 // echo $ty."-".$trieu;
        //                                 $price = $ty*(1000000000)+$trieu*(1000000);
        //                                 echo $price;
        //                             }
        //                             else
        //                             {
        //                                 $price = $ty*(1000000000);
        //                             }
                                    
                                    
                                   
        //                         }
                                


        //                         $contact = $result_arr['contact_name'];
        //                         $address = $result_arr['contact_add'];
        //                         $check_post_title   = $this->Mpost->check_post_title_exists($post_title); // return number rows


        //                         $data_insert  = array(
        //                             'post_title'        => $post_title,
        //                             'post_slug'         => $post_slug,
        //                             'post_content'      => $this->globals->get_the_content($post_content),
        //                             'cate_id'           => $cate_id,
        //                             'timestamp'         => $timestamp,
        //                             'province_id'       => $province_id,
        //                             'district_id'       => $district_id,
        //                             'price'             => $price,
        //                             'contact'           => trim($contact),
        //                             'feadtured_post'    => $feadtured,
        //                             'for_vip_user'      => $for_vip_user,
        //                             'active'            => $active,
        //                             'crawler_type'      => $crawler_type,
        //                             'unit' => "",
        //                             'area' => "1",

        //                         );
        //                         if ($check_post_title == 0) {
        //                             // $data_insert = $this->Mpost->insert($data_insert);
        //                             // echo $this->db->last_query($data_insert);
        //                         }
        //                         echo "<pre>";
        //                         print_r($result_arr);
        //                         echo "</pre>";
                                

        //                     }
        //                     // foreach ($a as $arr)
        //                     // {

        //                     //     $value = $this->crawler->get_dom_single_page($arr);

        //                     //     $result_arr = $this->crawler->get_data($value,$array);

        //                     //     $post_title = $result_arr['title'];

        //                     //     $post_slug = $this->globals->change_to_slug($result_arr['title']);

        //                     //     $post_content = $result_arr['desc'];

        //                     //     $cate_id = json_encode(array($cate_arr[$link_cate]));

        //                     //     $timestamp = strtotime(date('Y-m-d H:i:s'));

        //                     //     if (preg_match('/cho-thue/', $link_cate))
        //                     //     {
        //                     //         $unit = '/tháng';
        //                     //     }
        //                     //     else
        //                     //     {
        //                     //         $unit = '';
        //                     //     }

        //                     //     preg_match('/[0-9]+-[0-9]+-[0-9]+/', $result_arr['date_create'], $maches);
        //                     //     if ($maches)
        //                     //     {
        //                     //         $date = $maches[0];
        //                     //         $timestamp = strtotime($date);
        //                     //     }

        //                     //     $area_arr = explode('-', $result_arr['area']);

        //                     //     $province_name = $area_arr[count($area_arr)-1];

        //                     //     $province_id = $this->get_data->get_province_id_by_name($province_name);

        //                     //     $district_name = $area_arr[count($area_arr)-2];

        //                     //     $district_id = $this->get_data->get_district_id_by_name($district_name);

        //                     //     $feadtured          =  0;
        //                     //     $for_vip_user       =  0;
        //                     //     $active             =  1;
        //                     //     $crawler_type       =  1;

        //                     //     $price = $this->get_price($result_arr['price']);

        //                     //     $contact = '';

        //                     //     if (!empty($result_arr['table_bds2']))
        //                     //     {
        //                     //         preg_match('/([0-9]{10,11})/', implode(' ', $result_arr['table_bds2']), $maches);

        //                     //         if ($maches)
        //                     //         {
        //                     //             $contact = $maches[0];
        //                     //         }

        //                     //         else
        //                     //         {
        //                     //             $contact = '';
        //                     //         }
        //                     //     }
        //                     //     $area = '';

        //                     //     if (!empty($result_arr['square']))
        //                     //     {
        //                     //         preg_match('/([0-9]{1,})/', $result_arr['square'], $maches);

        //                     //         if ($maches)
        //                     //         {
        //                     //             $area = $maches[0];
        //                     //         }

        //                     //         else
        //                     //         {
        //                     //             $area = '';
        //                     //         }
        //                     //     }

        //                     //     $check_post_title   = $this->Mpost->check_post_title_exists($post_title); // return number rows


        //                     //     $data_insert  = array(
        //                     //         'post_title'        => $post_title,
        //                     //         'post_slug'         => $post_slug,
        //                     //         'post_content'      => $this->globals->get_the_content($post_content),
        //                     //         'cate_id'           => $cate_id,
        //                     //         'timestamp'         => $timestamp,
        //                     //         'province_id'       => $province_id,
        //                     //         'district_id'       => $district_id,
        //                     //         'price'             => $price,
        //                     //         'contact'           => trim($contact),
        //                     //         'feadtured_post'    => $feadtured,
        //                     //         'for_vip_user'      => $for_vip_user,
        //                     //         'active'            => $active,
        //                     //         'crawler_type'      => $crawler_type,
        //                     //         'unit' => $unit,
        //                     //         'area' => $area

        //                     //     );
        //                     //     if ($check_post_title == 0) {
        //                     //         //$data_insert = $this->Mpost->insert($data_insert);
        //                     //     }

        //                     // }

        //                     die();
        //                 }
        //             }

        //         }

        //     }
        // }
        

    }

     public function crawler_tinbatdongsan()
    {


        $cate_arr = $this->get_data->get_cate_by_crawl('tinbatdongsan');

       
        echo "<pre>";
        print_r($cate_arr);

        // if ($cate_arr)
        // {
        //     foreach ($cate_arr as $link_cate=>$cate_id)
        //     {
        //         if ($cate_arr[$link_cate])
        //         {

        //             // $pages = $this->crawler->get_list_url($link_cate, '.background-pager-right-controls', 'https://batdongsan.com.vn');

        //             $max_page = end($pages);

        //             $max_page = str_replace($link_cate, '', $max_page);

        //             $max_page = str_replace('/p', '', $max_page);
        //             $max_page = 15;

        //             if ($max_page>0)
        //             {
        //                 for ($i=$max_page; $i>=1; $i--)
        //                 {
        //                     if ($i>1)
        //                     {
        //                         // $a = $this->crawler->get_list_url($link_cate.'/p'.$i,'.p-title','https://batdongsan.com.vn');

        //                         $a = $this->crawler->get_list_url($link_cate.'/trang--'.$i.'.html','.ct_title','http://123nhadatviet.com');
        //                     }
        //                     else
        //                     {
        //                         // $a = $this->crawler->get_list_url($link_cate,'.p-title','https://batdongsan.com.vn');
        //                     }

        //                     $array = array(
        //                     'title' => '{"element":"div.title","count":0}',
        //                     'area' => '{"element":"div.address .value","count":0,"convert":"true"}',
        //                     // 'price' => '{"element":"span.price","count":0}',
        //                     // // 'square' => '{"element":"label.lb-pri-dt strong","count":1}',
        //                     'desc'   => '{"element":"div.detail","count":0}',
        //                     'galerry' => '{"element":".image-list ul li img","count":0,"loop":"true"}',
        //                     // // 'map_lat'     =>  '{"element":"input#txtLAT","count":0,"map_":"value"}',
        //                     // // 'map_long'     =>  '{"element":"input#txtLON","count":0,"map_":"value"}',
        //                     'table_bds'     =>  '{"element":".infor tr td","count":0,"loop_i_nha_dat":"true","convert":"true"}',

        //                     'contact_name'     =>  '{"element":".contact-info .content .name","count":0}',
        //                     'contact_add'     =>  '{"element":".contact-info .content .fone a","count":0}',
        //                     // // 'contact_phone'     =>  '{"element":"a#viewmobinumber","count":0}',
        //                     // // // 'table_bds2'     =>  '{"element":"div.table-detail ","count":1,"loop":".right-content","convert":"true"}',
        //                     // 'date_create'     =>  '{"element":"span#MainContent_ctlDetailBox_lblDateCreated","count":0}',
        //                     );

        //                     foreach ($a as $arr) {
        //                         $value =  $this->crawler->get_dom_single_page($arr);
        //                         $result_arr =  $this->crawler->get_data($value,$array,"http://123nhadatviet.com");
        //                         // echo $arr."<br>";
        //                         $post_title = $result_arr['title'];
        //                         $post_slug = $this->globals->change_to_slug($result_arr['title']);
        //                         $post_content = $result_arr['desc'];
        //                         $timestamp = date('Y-m-d H:i:s');
        //                         $post_thumbnai = $result_arr['galerry'][0];
        //                         $cate_id = json_encode(array($cate_arr[$link_cate]));
        //                         $area_arr = explode('-', $result_arr['area']);

        //                         $province_name = $area_arr[count($area_arr)-1];

        //                         $province_id = $this->get_data->get_province_id_by_name($province_name);

        //                         $district_name = $area_arr[count($area_arr)-2];

        //                         $district_id = $this->get_data->get_district_id_by_name($district_name);

        //                         $feadtured          =  0;
        //                         $for_vip_user       =  0;
        //                         $active             =  1;
        //                         $crawler_type       =  1;
        //                         $index = 0;
        //                         foreach ($result_arr['table_bds'] as $key => $value) {
                                   
        //                             $newkey = $this->globals->change_to_slug($key);
        //                             $result_arr['table_bds'][$index] = $result_arr['table_bds'][$key];
        //                             unset($result_arr['table_bds'][$key]);
        //                             $index++;
        //                         }
        //                         $price = $result_arr['table_bds'][17];
        //                         $price = strval($price);
        //                         // echo $price."<br>";
        //                         // $i1 = strpos($price, '</');
        //                         // echo $i1."<br>";

        //                         // if($i1)
        //                         // {
        //                         //     $abc = substr($price, 30,$i1-30);
        //                         //     echo $abc."<br>";
        //                         // }
        //                         preg_match_all("/<td colspan='3' class='price'>(.*?)<\/td>/", $price, $matches);
        //                         $price = $matches[1][0];
        //                         //echo $price;
        //                         if ($ity = strpos($price, 'tỷ') !== false) 
        //                         {
                                
        //                             // $ty = substr($price, 0,$ity+3);
        //                             preg_match_all("/(.*?) tỷ/", $price, $matchesTy);
                                    
        //                             $ty = $matchesTy[1][0];
        //                             echo $ty."<br>";
        //                             if ($idot = strpos($ty,',') !== false)
        //                             {
        //                                 $trieu = substr($ty,$ity+1);
                                      

        //                                 if($trieu/100<1)
        //                                 {
                                            
        //                                     if($trieu/10<1)
        //                                     {
        //                                         $trieu = $trieu*100;
        //                                     }
        //                                     else
        //                                         $trieu = $trieu*10;
        //                                 }
        //                                 echo $trieu."<br>";
        //                                 $ty = substr($ty, 0,$ity);
                                        
        //                                 // echo $ty."-".$trieu;
        //                                 $price = $ty*(1000000000)+$trieu*(1000000);
        //                                 echo $price;
        //                             }
        //                             else
        //                             {
        //                                 $price = $ty*(1000000000);
        //                             }
                                    
                                    
                                   
        //                         }
        //                         else if ($itrieu = strpos($price, 'triệu') !== false) 
        //                         {
                                
        //                             // $ty = substr($price, 0,$ity+3);
        //                             preg_match_all("/(.*?) tỷ/", $price, $matchesTy);
                                    
        //                             $ty = $matchesTy[1][0];
        //                             echo $ty."<br>";
        //                             if ($idot = strpos($ty,',') !== false)
        //                             {
        //                                 $trieu = substr($ty,$ity+1);
                                      

        //                                 if($trieu/100<1)
        //                                 {
                                            
        //                                     if($trieu/10<1)
        //                                     {
        //                                         $trieu = $trieu*100;
        //                                     }
        //                                     else
        //                                         $trieu = $trieu*10;
        //                                 }
        //                                 echo $trieu."<br>";
        //                                 $ty = substr($ty, 0,$ity);
                                        
        //                                 // echo $ty."-".$trieu;
        //                                 $price = $ty*(1000000000)+$trieu*(1000000);
        //                                 echo $price;
        //                             }
        //                             else
        //                             {
        //                                 $price = $ty*(1000000000);
        //                             }
                                    
                                    
                                   
        //                         }
                                


        //                         $contact = $result_arr['contact_name'];
        //                         $address = $result_arr['contact_add'];
        //                         $check_post_title   = $this->Mpost->check_post_title_exists($post_title); // return number rows


        //                         $data_insert  = array(
        //                             'post_title'        => $post_title,
        //                             'post_slug'         => $post_slug,
        //                             'post_content'      => $this->globals->get_the_content($post_content),
        //                             'cate_id'           => $cate_id,
        //                             'timestamp'         => $timestamp,
        //                             'province_id'       => $province_id,
        //                             'district_id'       => $district_id,
        //                             'price'             => $price,
        //                             'contact'           => trim($contact),
        //                             'feadtured_post'    => $feadtured,
        //                             'for_vip_user'      => $for_vip_user,
        //                             'active'            => $active,
        //                             'crawler_type'      => $crawler_type,
        //                             'unit' => "",
        //                             'area' => "1",

        //                         );
        //                         if ($check_post_title == 0) {
        //                             // $data_insert = $this->Mpost->insert($data_insert);
        //                             // echo $this->db->last_query($data_insert);
        //                         }
        //                         echo "<pre>";
        //                         print_r($result_arr);
        //                         echo "</pre>";
                                

        //                     }
                            

        //                     die();
        //                 }
        //             }

        //         }

        //     }
        // }
        

    }

    // phuc crawler nhadat24h
    public function crawler_nhadat24h(){
        $cate_arr = $this->get_data->get_cate_by_crawl('nhadat24h');
        
        if ($cate_arr)
        {
            foreach ($cate_arr as $link_cate => $cate_id) {
                if ($cate_arr[$link_cate])
                {
                    // $pages = $this->crawler->get_list_url(str_replace('.html', '', $link_cate).'/p10000.htm', '.pager_controls', 'https://dothi.net');
                    // $max_page = end($pages);

                    // $max_page = str_replace(str_replace('.htm', '', $link_cate), '', $max_page);

                    // $max_page = str_replace('/p', '', $max_page);

                    // $max_page = str_replace('.htm', '', $max_page);

                    $max_page = 1;


                    for ($i=$max_page; $i>=1; $i++)
                    {
                        $a = $this->crawler->get_list_url($link_cate."?page=".$i,'.bdsinfo h2');
                        $array = array(
                            'title' => '{"element":"div.heading-page h1","count":0}',
                            
                            'price' => '{"element":"div.box-orange strong","count":0}',
                    
                            'square' => '{"element":"div.box-orange strong","count":1}',
                    
                            'area' => '{"element":"h2.khuvuc a strong","count":0}',
                    
                            'desc'   => '{"element":"div.bdsmota p","count":0}',
                    
                            'galerry' => '{"element":"div[u=slides] div img","count":0,"loop":"true"}',
                            // // // 'map_lat'     =>  '{"element":"input#txtLAT","count":0,"map_":"value"}',
                            // // // 'map_long'     =>  '{"element":"input#txtLON","count":0,"map_":"value"}',
                            'table_bds'     =>  '{"element":".dacdiemlienhe .pull-left ul li","count":0,"loop_nhadat24h_tbs":"true","convert":"true"}',
                    
                            'table_contact'     =>  '{"element":".dacdiemlienhe .pull-right ul li","count":0,"loop_nhadat24h_tbs":"true","convert":"true"}',
                    
                            // 'contact_name'     =>  '{"element":".contact-info .content .name","count":0}',
                            // 'contact_add'     =>  '{"element":".contact-info .content .fone a","count":0}',
                            // 'contact_phone'     =>  '{"element":"div.box-orange strong","count":2}',
                            // // // // 'table_bds2'     =>  '{"element":"div.table-detail ","count":1,"loop":".right-content","convert":"true"}',
                            // // 'date_create'     =>  '{"element":"span#MainContent_ctlDetailBox_lblDateCreated","count":0}',
                        );

                        foreach ($a as $arr) {
                            $value = $this->crawler->get_dom_single_page($arr);
                            $result_arr = $this->crawler->get_data($value,$array);
                                // echo $arr."<br>";
                                        echo "<pre>";
                                        print_r($result_arr);
                                        echo "</pre>";
                            $post_title = $result_arr['title'];

                            $post_slug = $this->globals->change_to_slug($result_arr['title']);

                            $post_content = $result_arr['desc'];

                            $cate_id = json_encode(array((string)$cate_arr[$link_cate]));

                            $timestamp = strtotime(date('Y-m-d H:i:s'));

                            $area_arr = explode(',', $result_arr['area']);

                            $province_name = $area_arr[count($area_arr)-1];

                             if (trim($province_name)=='TP.HCM')
                             {
                                 $province_name = 'Hồ Chí Minh';
                             }

                            $province_id = $this->get_data->get_province_id_by_name(trim($province_name));

                            $district_name = $area_arr[count($area_arr)-2];

                            $district_id = $this->get_data->get_district_id_by_name(trim($district_name));

                            $feadtured   		=  0;
                            $for_vip_user 		=  0;
                            $active       		=  1;
                            $crawler_type 		=  1;

                            $price = 0;

                            if ($result_arr['price'])
                            {
                                $price = $this->get_price(trim(mb_strtolower($result_arr['price'])));
                            }

                            $contact = '';

                            if ($result_arr['table_contact']['Điện thoại: '])
                            {
                                $contact = str_replace('.', '', trim($result_arr['table_contact']['Điện thoại: ']));
                            }

                            echo '<pre>';
                            print_r($result_arr);
                            echo '</pre>';


                            //  $area = '';

                            if (preg_match('/cho-thue/', $link_cate))
                            {
                                $unit = '/tháng';
                            }
                            else
                            {
                                $unit = '';
                            }

                            $area = '';

                            if (!empty($result_arr['square']))
                            {
                                preg_match('/([0-9]{1,})/', $result_arr['square'], $maches);

                                if ($maches)
                                {
                                    $area = $maches[0];
                                }

                                else
                                {
                                    $area = '';
                                }
                            }

                            if ($result_arr['table_bds']['Ngày đăng tin'])
                            {
                                $date = trim($result_arr['table_bds']['Ngày đăng tin']);

                                $date = strip_tags($date);

                                $date = trim($date);

                                $date_object = date_create_from_format('d/m/Y', $date);

                                if ($date_object)
                                {
                                    $timestamp = strtotime($date_object->format('Y-m-d'));
                                    // echo $timestamp;
                                }

                            }

                            $check_post_title 	= $this->Mpost->check_post_title_exists($post_title);

                            $data_insert  = array(
                                'post_title'  		=> $post_title,
                                'post_slug'  		=> $post_slug,
                                'post_content' 	=> $this->globals->get_the_content($post_content),
                                'cate_id'			=> $cate_id,
                                'timestamp'			=> $timestamp,
                                'province_id'  		=> $province_id,
                                'district_id' 		=> $district_id,
                                'price'				=> $price,
                                'contact'			=> strip_tags(trim($contact)),
                                'feadtured_post'   	=> $feadtured,
                                'for_vip_user' 		=> $for_vip_user,
                                'active'			=> $active,
                                'crawler_type'		=> $crawler_type,
                                'unit' => $unit,
                                'area' => $area

                            );
                            if ($check_post_title == 0) {
                                $data_insert = $this->Mpost->insert($data_insert);
                            }
                        }
                    }
                }
            }
        }

    }
    // phuc crawler kenh_batdongsan
    public function crawler_kenhbatdongsan(){
        $cate_arr = $this->get_data->get_cate_by_crawl('kenhbds');
        if($cate_arr){
            foreach ($cate_arr as $link_cate => $cate_id) {
                if ($cate_arr[$link_cate])
                {
                    // $pages = $this->crawler->get_list_url(str_replace('.html', '', $link_cate).'/p10000.htm', '.pager_controls', 'https://dothi.net');
                    // $max_page = end($pages);

                    // $max_page = str_replace(str_replace('.htm', '', $link_cate), '', $max_page);

                    // $max_page = str_replace('/p', '', $max_page);

                    // $max_page = str_replace('.htm', '', $max_page);

                    $max_page = 2;


                    for ($i=$max_page; $i>=1; $i++)
                    {
                        $a = $this->crawler->get_list_url($link_cate."?&per_page=".$i,'.tt_dong1');

                        $array = array(
                            'title' => '{"element":"div.tit3 h1","count":0}',
                            
                            // 'price' => '{"element":"div.c3_tt p","count":5,"findtext":1}',
                    
                            // 'square' => '{"element":"div.c3_tt p","count":4,"findtext":1}',
                    
                            // 'area' => '{"element":"div.c3_tt p","count":3,"findtext":1}',
                    
                            'desc'   => '{"element":"div.detail_ct","count":0}',
                            
                            // 'contact_phone' => '{"element":"div.c3_tt p","count":3,"findtext":1}',
                            // 'galerry' => '{"element":"div[u=slides] div img","count":0,"loop":"true"}',
                            // // // 'map_lat'     =>  '{"element":"input#txtLAT","count":0,"map_":"value"}',
                            // // // 'map_long'     =>  '{"element":"input#txtLON","count":0,"map_":"value"}',
                            'table_bds'     =>  '{"element":".c3_tt p","count":0,"loop_kenhbatdongsan":"true","convert":"true"}',
                    
                            // 'table_contact'     =>  '{"element":".dacdiemlienhe .pull-right ul li","count":0,"loop_nhadat24h_tbs":"true","convert":"true"}',
                    
                            // 'contact_name'     =>  '{"element":".contact-info .content .name","count":0}',
                            // 'contact_add'     =>  '{"element":".contact-info .content .fone a","count":0}',
                            // 'contact_phone'     =>  '{"element":"div.box-orange strong","count":2}',
                            // // // // 'table_bds2'     =>  '{"element":"div.table-detail ","count":1,"loop":".right-content","convert":"true"}',
                            // // 'date_create'     =>  '{"element":"span#MainContent_ctlDetailBox_lblDateCreated","count":0}',
                        );

                        foreach ($a as $arr) {
                            $value = $this->crawler->get_dom_single_page($arr);
                            $result_arr = $this->crawler->get_data($value,$array);
                            $post_title = $result_arr['title'];

                            $post_slug = $this->globals->change_to_slug($result_arr['title']);

                            $post_content = $result_arr['desc'];

                            $cate_id = json_encode(array((string)$cate_arr[$link_cate]));

                            $timestamp = strtotime(date('Y-m-d H:i:s'));

                            $area_arr = explode('-', $result_arr['table_bds']['Khu vực:']);

                            $province_name = $area_arr[count($area_arr)-1];

                             if (trim($province_name)=='TP.HCM')
                             {
                                 $province_name = 'Hồ Chí Minh';
                             }

                            $province_id = $this->get_data->get_province_id_by_name(trim($province_name));

                            $district_name = $area_arr[count($area_arr)-2];

                            $district_id = $this->get_data->get_district_id_by_name(trim($district_name));

                            $feadtured   		=  0;
                            $for_vip_user 		=  0;
                            $active       		=  1;
                            $crawler_type 		=  1;

                            $price = 0;
                            
                            if ($result_arr['table_bds']['Giá:'])
                            {
                                $price = $this->convert_price_kenhbds($result_arr['table_bds']['Giá:']);
                            }

                            $contact = '';

                            if ($result_arr['table_bds']['Điện thoại:'])
                            {
                                $contact = str_replace('.', '', trim($result_arr['table_bds']['Điện thoại:']));
                            }


                            if (preg_match('/cho-thue/', $link_cate))
                            {
                                $unit = '/tháng';
                            }
                            else
                            {
                                $unit = '';
                            }
                            // dieenjn tích 
                            $squre = '';

                            if (!empty($result_arr['table_bds']['Diện tích:']))
                            {
                                preg_match('/([0-9]{1,})/', $result_arr['table_bds']['Diện tích:'], $maches);

                                if ($maches)
                                {
                                    $squre = $maches[0];
                                }

                                else
                                {
                                    $squre = '';
                                }
                            }

                            if ($result_arr['table_bds']['Ngày đăng tin:'])
                            {
                                $date = trim($result_arr['table_bds']['Ngày đăng tin:']);

                                $date = strip_tags($date);

                                $date = trim($date);

                                $date_object = date_create_from_format('d/m/Y', $date);

                                if ($date_object)
                                {
                                    $timestamp = strtotime($date_object->format('Y-m-d'));
                                    // echo $timestamp;
                                }

                            }

                            $check_post_title 	= $this->Mpost->check_post_title_exists($post_title);

                            $data_insert  = array(
                                'post_title'  		=> $post_title,
                                'post_slug'  		=> $post_slug,
                                'post_content' 	=> $this->globals->get_the_content($post_content),
                                'cate_id'			=> $cate_id,
                                'timestamp'			=> $timestamp,
                                'province_id'  		=> $province_id,
                                'district_id' 		=> $district_id,
                                'price'				=> $price,
                                'contact'			=> strip_tags(trim($contact)),
                                'feadtured_post'   	=> $feadtured,
                                'for_vip_user' 		=> $for_vip_user,
                                'active'			=> $active,
                                'crawler_type'		=> $crawler_type,
                                'unit' => $unit,
                                'area' => $area

                            );

                            echo '<pre>';
                            print_r($data_insert);
                            echo '</pre>';
                            // if ($check_post_title == 0) {
                            //     $data_insert = $this->Mpost->insert($data_insert);
                            // }
                        }
                    }
                }
            }
        }

    }





}
?>