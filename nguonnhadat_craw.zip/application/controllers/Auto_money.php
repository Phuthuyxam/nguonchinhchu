<?php 
   /**
    * 
    */
   class Auto_money extends CI_Controller
   {
   	
   	function __construct()
   	{
   		parent::__construct();
   		$this->load->helper('url');
   		$this->load->model('Mauto_money');
   		$this->load->model('Muser');
   		$this->load->model('Muser_payments');
        $this->load->library('Get_data');
   		
   	}
   	// trừ tiền theo ngày
   	public function index()
   	{
   		
   		$now = date('Y-m-d');
        $header_info = $this->get_data->options_info("header");
   		$amount_cost = $header_info->money_fee;
   		$amount_user = '';
   		$result      = '';
   		$all_user = $this->Muser->get_all_user();
   		foreach ($all_user as $items ) {
   			$id                   =  $items['user_id'];
   			$amount_user          =  $items['amount'];
   			$result               =  $amount_user - $amount_cost;


   			if ($this->Mauto_money->check_logs($id, $now))
            {
                if ($result<0)
                {
                    $result = 0;
                }
                $data = array(
                    'amount' => $result

                );
                // trừ tiền
                $this->Muser_payments->update($id,$data);
                $data_money = array(
                    'timestamp' => date('Y-m-d'),
                    'user_id'   => $id

                );
                // Thêm bản ghi danh sách trừ tiền
                $this->Mauto_money->insert_money_logs($data_money);
            }
            else
            {

            }



   			// var_dump($money_logs_user);
   			// die();
//   			if ()
//   			{
//
//   			}


   		}
   		
   	}
   }

   ?>