<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class post extends CI_Controller {

	protected $_data;
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Mpost');
		$this->load->model('Muser');
		$this->load->model('Mcategory');
		$this->load->model('Mprovince');
		$this->load->library('Globals');
		$this->load->library('Get_data');

	}

	
	public function index()
	{
		$this->_data['page_title'] = "Danh sách tin thường";
		$this->_data['head_title'] = "Quản lý tin thường";

		$this->_data['for_vip'] = 0;

		$this->_data['list_province'] = $this->Mprovince->get_all_province();

		$this->_data['category_parent'] = $this->Mcategory->ad_get_cate_child_active(0);

		$this->load->view('admin/post/lists.php', $this->_data);

	}

	public function get_list_post_data($for_vip=0)
	{
		header('Content-Type: application/json');

		$filter = array('for_vip_user'=>$for_vip);

		if ($this->input->get('province_id'))
		{
			$province_id = $this->input->get('province_id');
			$filter['province_id'] = $province_id;
		}
		else
		{
			$filter['province_id'] = 1;
		}

		if ($this->input->get('district_id'))
		{
			$district_id = $this->input->get('district_id');
			$filter['district_id'] = $district_id;
		}
		if ($this->input->get('area'))
		{
			$area = $this->input->get('area');
			$area_arr = explode('-', $area);
			if ($area_arr[0]>0)
			{
				$filter['area<='] = $area_arr[0];
			}

			if ($area_arr[1]>0)
			{
				$filter['area>='] = $area_arr[1];
			}

		}

		if ($this->input->get('date_start'))
		{
			$date_start = $this->input->get('date_start').' 00:00:00';
			$date_start = strtotime($date_start);
			$filter['timestamp>='] = $date_start;
		}

		if ($this->input->get('date_end'))
		{
			$date_end = $this->input->get('date_end').' 23:59:59';
			$date_end = strtotime($date_end);
			$filter['timestamp<='] = $date_end;
		}

		$keyword = '';

		if ($this->input->get('keyword'))
		{
			$keyword = $this->input->get('keyword');
		}

		if ($this->input->get('category_id'))
		{
			$category_id = $this->input->get('category_id');

			if ($this->Mcategory->ad_get_cate_child($category_id))
			{
				$list_cate = array();
				foreach ($this->Mcategory->ad_get_cate_child($category_id) as $cate)
				{
					$list_cate[] = json_encode(array($cate['cate_id']));
				}

				$category = $list_cate;

			}
			else
			{
				$filter['cate_id'] = json_encode(array($category_id));
			}
		}

		$all_post = $this->Mpost->get_all_post($filter, $keyword, $category);


		$response = array();

        /*
        foreach ($all_post as $key => $item) {
            $user_info = $this->Muser->get_user_by('user_id',$item['user_id']);
            $all_post[$key]['user_fullname'] = $user_info['fullname'];

            $cate_id = json_decode($item['cate_id']);
            if($cate_id){
                $all_post[$key]['cate_name'] = [];
                foreach ($cate_id as $id) {
                    $cate_info = $this->Mcategory->ad_get_cate_by('cate_id',$id);
                    $all_post[$key]['cate_name'][] = $cate_info['cate_name'];
                }
            }

        }
        */

        if ($all_post)
        {
        	$count = 0;
        	foreach ($all_post as $item)
        	{
        		$count++;
        		$price = ($item['price'])?number_format($item['price']):'Thỏa thuận';
        		$area = $this->get_data->get_district($item['district_id']).' - '.$this->get_data->get_province($item['province_id']);
        		if (trim($area)=='-')
        		{
        			$area = '';
        		}
        		$handling = ($item['handling']==0)?'<span class="label label-warning">Chưa xử lý</span>':'<span class="label label-success">Xử lý</span>';
        		$active = ($item['active']==0)?'<span class="label label-warning">Chưa kích hoạt</span>':'<span class="label label-success">Kích hoạt</span>';
        		$edit = '<a href="'.base_url("admin/post/edit/".$item["post_id"]).'" class="btn btn-primary btn-block"><i class="fa fa-edit"></i></a>';
        		$delete = '<a href="'.base_url("admin/post/del/".$item["post_id"]).'" style="margin-left: 0px;" class="btn btn-danger btn-block" onclick="return confirm(\'Bạn có chắc chắn muốn xóa?\');"><i class="fa fa-trash-o"></i></a>';
        		$date_create = date('d/m/Y', $item['timestamp']);
        		$value = array($count, $item['post_title'], $area, $price, $date_create, $active, $handling, $edit.$delete);

        		$response['data'][] = $value;
        	}
        }

        if (empty($response))
        {
        	$response['data'] = array();
        }
        echo json_encode($response);
    }

    public function post_vip()
    {
    	$this->_data['page_title'] = "Danh sách tin VIP";
    	$this->_data['head_title'] = "Quản lý tin VIP";

    	$this->_data['for_vip'] = 1;

    	$this->_data['category_parent'] = $this->Mcategory->ad_get_cate_child_active(0);

    	$this->_data['list_province'] = $this->Mprovince->get_all_province();
    	$this->load->view('admin/post/lists.php', $this->_data);

    }

    public function export_post()
    {
    	$all_post = $this->Mpost->get_all_post();
    	foreach ($all_post as $key => $item) {
    		$user_info = $this->Muser->get_user_by('user_id',$item['user_id']);
    		$all_post[$key]['user_fullname'] = $user_info['fullname'];

    		$cate_id = json_decode($item['cate_id']);
    		if($cate_id){
    			$all_post[$key]['cate_name'] = '';
    			$d = 0;
    			foreach ($cate_id as $id) {
    				$d++;
    				if($d>1) $all_post[$key]['cate_name'].=", ";
    				$cate_info = $this->Mcategory->ad_get_cate_by('cate_id',$id);
    				$all_post[$key]['cate_name'].= $cate_info['cate_name'];
    			}
    		}
    	}
    	$list_export = [];
    	$th_array = array(
    		'B' => 'Tiêu đề',
    		'C' => 'Chuyên mục',
    		'D' => 'Ngày đăng',
    		'E' => 'Người đăng',
    		'F' => 'Loại tin',
    	);
    	$tr_array = [];
    	foreach ($all_post as $item) {
    		$str_feat = ($item['for_vip_user']==0)?"Tin thường":"Tin VIP";
    		$tr_array[] = array(
    			'B' => $item['post_title'],
    			'C' => $item['cate_name'],
    			'D' => date("d/m/Y H:i:s",$item['timestamp']),
    			'E' => $item['user_fullname'],
    			'F' => $str_feat
    		);
    	}
    	$this->globals->my_export("list_posts","Danh sách tin đăng",$th_array,$tr_array);
    }

	// Đệ quy cate
    public function get_cate_recursive($parent_id=0,$result='',$str=''){
    	if(!is_array($result)){
    		$result = [];
    	}
    	$get_cate = $this->Mcategory->ad_get_cate_child($parent_id);
    	foreach ($get_cate as $item) {
    		$item_cate = $item;
    		$item_cate['display'] = $str.' '.$item['cate_name'];
    		$result[] = $item_cate;
    		$result = $this->get_cate_recursive($item['cate_id'],$result,$str.'---');
    	}
    	return $result;
    }

	// Thêm mới
    public function add(){
    	$this->_data['page_title'] = "Thêm mới tin tức";
    	$this->_data['head_title'] = "Quản lý tin tức";
    	$this->_data['all_user'] = $this->Muser->get_all_user();
    	$this->_data['all_cate'] = $this->get_cate_recursive();
    	$login = $this->session->get_userdata();
    	$login = $login['admin_info'];
    	$this->_data['list_province'] = $this->Mprovince->get_all_province();
    	$msg = '';
    	$data_post = '';
    	$this->form_validation->set_rules("post_title","Tiêu đề","required|trim|is_unique[posts.post_title]");

    	if($this->form_validation->run() == true){
    		$post_title = $this->input->post("post_title");
    		$cate_id = $this->input->post("cate_id");
    		$active = ($this->input->post("active"))?1:0;
    		$handling = ($this->input->post("handling"))?1:0;
    		$feadtured_post = ($this->input->post("feadtured_post"))?1:0;
    		$for_vip_user = ($this->input->post("for_vip_user"))?1:0;
    		$timestamp = strtotime(date('Y-m-d H:i:s'));
    		$slug = $this->input->post("post_slug");

            if(empty($slug)) $slug = $this->globals->change_to_slug($post_title);
            $data = array(
               "thumbnail" 			=> $this->input->post("thumbnail"),
               "post_title" 			=> $post_title,
               "post_slug" 			=> $slug,
               "post_content" 			=> $this->input->post("post_content"),
               "province_id" 			=> $this->input->post("province_id"),
               "district_id" 			=> $this->input->post("district_id"),
               "price" 				=> $this->input->post("price"),
               "area" 					=> $this->input->post("area"),
               "contact" 				=> $this->input->post("contact"),
               "address" 				=> $this->input->post("address"),
               "cate_id" 				=> json_encode($cate_id),
               "timestamp" 			=> ($timestamp)?$timestamp:time(),
               "user_id" 				=> $login["admin_id"],
               "feadtured_post" 		=> $feadtured_post,
               "for_vip_user" 			=> $for_vip_user,
               "active" 				=> $active,
               "handling" 				=> $handling,
               "unit" 					=> $this->input->post("unit"),
               'crawler_type' 			=> 0
           );
            $data_post = $data;

            if($cate_id){
               if($this->Mpost->check_post_title_exists($post_title)){
                $msg = array(
                 "type" => "danger",
                 "content" => "Tiêu đề đã tồn tại"
             );
            }else{
                    // var_dump($data);die;
                $insert_id = $this->Mpost->insert($data);
                if($insert_id>0){

                 if ($for_vip_user==1)
                 {
                  $data['for_vip_user'] = $for_vip_user;
                  $data['clone'] = 1;
                  $data['timestamp'] = ($timestamp)?$timestamp:time();
                  $data['user_id'] = $login["admin_id"];
                  $this->Mpost->insert($data);
              }

              if ($this->input->post('images'))
              {
                foreach($this->input->post('images') as $item)
                {
                    $this->Mpost->insert_post_images(array('image_url'=> base_url().$path_img, 'post_id'=>$insert_id));
                }
                
            }
            $msg = array(
              "type" => "success",
              "content" => "Thêm mới thành công"
          );
            $this->session->set_flashdata('msg', $msg);
            redirect('admin/post/edit/'.$insert_id);
        }else{
         $msg = array(
          "type" => "danger",
          "content" => "Thêm mới không thành công!"
      );
     }
 }
}else{
   $msg = array(
    "type" => "danger",
    "content" => "Danh mục tin tức bắt buộc phải chọn!"
);
}
}

$this->_data['msg'] = $msg;
$this->_data['data_post'] = $data_post;
$this->load->view('admin/post/add.php', $this->_data);
}

	// Sửa
public function edit(){
 $id = $this->uri->segment(4);
 if($id){
  $check = $this->Mpost->check_post_id($id);
  if($check==0){
   redirect('admin/post','refresh');
}
}else{
  redirect('admin/post','refresh');
}
$this->_data['images'] = $this->db->query('select image_url from post_image where post_id = '.$id.'')->result();

$this->_data['page_title'] = "Cập nhật tin tức";
$this->_data['head_title'] = "Quản lý tin tức";
$this->_data['all_user'] = $this->Muser->get_all_user();
$this->_data['all_cate'] = $this->get_cate_recursive();

$this->_data['post_images'] = $this->Mpost->get_post_images($id);

$this->_data['list_province'] = $this->Mprovince->get_all_province();

$current_post = $this->Mpost->get_post_by('post_id',$id);

$msg = '';
$this->form_validation->set_rules("post_title","Tên doanh nghiệp","required|trim");

if($this->form_validation->run() == true){
  $post_title = $this->input->post("post_title");
  if($this->Mpost->check_post_title_exists($post_title,$id)){
   $msg = array(
    "type" => "danger",
    "content" => "Tiêu đề bài viết đã tồn tại"
);
}else{
   $active = ($this->input->post("active"))?1:0;
   $handling = ($this->input->post("handling"))?1:0;
   $feadtured_post = ($this->input->post("feadtured_post"))?1:0;
   $for_vip_user = ($this->input->post("for_vip_user"))?1:0;
   $cate_id = $this->input->post("cate_id");

   $slug = $this->input->post("post_slug");
   if(empty($slug)) $slug = $this->globals->change_to_slug($post_title);
   $data = array(
    "thumbnail" => $this->input->post("thumbnail"),
    "post_title" => $post_title,
    "post_slug" => $slug,
    "post_content" => $this->input->post("post_content"),
    "cate_id" => json_encode( $cate_id ),
    "feadtured_post" => $feadtured_post,
    "active" => $active,
    "province_id" => $this->input->post("province_id"),
    "district_id" => $this->input->post("district_id"),
    "price" => $this->input->post("price"),
    "area" => $this->input->post("area"),
    "contact" => $this->input->post("contact"),
    "address" => $this->input->post("address"),
    "unit" => $this->input->post('unit'),
    "handling" => $handling,
    "crawler_type" => 0
);
   $update_stt = $this->Mpost->update($id,$data);
   if($update_stt){

				    //Duplicate post if for_vip_user=1

    if ($for_vip_user==1 && $current_post['clone']==0)
    {
     $data['for_vip_user'] = $for_vip_user;
     $data['clone'] = 1;
     $data['timestamp'] = $current_post['timestamp'];
     $data['user_id'] = $current_post['user_id'];
     $this->Mpost->insert($data);
 }

 $this->Mpost->delete_post_images($id);

 if ($this->input->post('images'))
 {
     foreach ($this->input->post('images') as $item)
     {
        $this->Mpost->insert_post_images(array('image_url'=> base_url().$item, 'post_id'=>$id));
    }
}

$msg = array(
 "type" => "success",
 "content" => "Cập nhật thành công"
);
}else{
    $msg = array(
     "type" => "danger",
     "content" => "Cập nhật không thành công!"
 );
}
}
}
$this->_data['msg'] = $msg;
$this->_data['current_post'] = $this->Mpost->get_post_by('post_id',$id);

$this->load->view('admin/post/edit.php', $this->_data);
}

	// Del
public function del(){
 $msg = '';
 $id = $this->uri->segment(4);
 if($id){
  $check = $this->Mpost->check_post_id($id);
  if($check==0){
   $msg = array(
    'type' => 'danger',
    'content' => 'Tin tức không tồn tại!'
);
}
}else{
  redirect('admin/post');
}

if($this->Mpost->delete($id)){
  $msg = array(
   'type' => 'success',
   'content' => 'Xóa tin tức thành công!'
);
}else{
  $msg = array(
   'type' => 'danger',
   'content' => 'Xóa không thành công!'
);
}

$this->session->set_flashdata('msg', $msg);
redirect('admin/post');
}

public function load_district()
{
 $province_id = $this->input->post('province_id');
 $list_district = $this->Mprovince->get_list_district($province_id);
 echo json_encode($list_district);
}


public function manager_post_crawl()
{
 $this->_data['head_title'] 		= 	'Quản lý danh mục tin đăng tự động';
 $this->_data['page_title']   	= 	'Danh mục tin đăng tự động';

 $this->load->view('admin/post/lists_post_crawl.php', $this->_data);
}

public function manager_post_crawl_data()
{
 header('Content-Type: application/json');

 $filter = array();

 if ($this->input->get('province_id'))
 {
  $province_id = $this->input->get('province_id');
  $filter['province_id'] = $province_id;
}
if ($this->input->get('district_id'))
{
  $district_id = $this->input->get('district_id');
  $filter['district_id'] = $district_id;
}
if ($this->input->get('area'))
{
  $area = $this->input->get('area');
  $area_arr = explode('-', $area);
  if ($area_arr[0]>0)
  {
   $filter['area<='] = $area_arr[0];
}

if ($area_arr[1]>0)
{
   $filter['area>='] = $area_arr[1];
}

}

$all_post = $this->Mpost->get_all_post($filter, 2);


$response = array();

foreach ($all_post as $key => $item) {
  $user_info = $this->Muser->get_user_by('user_id',$item['user_id']);
  $all_post[$key]['user_fullname'] = $user_info['fullname'];

  $cate_id = json_decode($item['cate_id']);
  if($cate_id){
   $all_post[$key]['cate_name'] = [];
   foreach ($cate_id as $id) {
    $cate_info = $this->Mcategory->ad_get_cate_by('cate_id',$id);
    $all_post[$key]['cate_name'][] = $cate_info['cate_name'];
}
}

}

if ($all_post)
{
  $count = 0;
  foreach ($all_post as $item)
  {
   $count++;
   $price = ($item['price'])?number_format($item['price']):'Thỏa thuận';
   $type = ($item["crawler_type"]==1)?'Chủ nhà':'Môi giới';
   $area = $this->get_data->get_district($item['district_id']).' - '.$this->get_data->get_province($item['province_id']);
   if (trim($area)=='-')
   {
    $area = '';
}
$edit = '<a href="'.base_url("admin/post/edit_crawl/".$item["post_id"]).'" class="btn btn-primary btn-block"><i class="fa fa-edit"></i></a>';
$delete = '<a href="'.base_url("admin/post/del_crawl/".$item["post_id"]).'" style="margin-left: 0px;" class="btn btn-danger btn-block" onclick="return confirm(\'Bạn có chắc chắn muốn xóa?\');"><i class="fa fa-trash-o"></i></a>';
$date_create = date('d/m/Y', $item['timestamp']);
$value = array($count, $item['post_title'], $item['cate_name'][0], $price, $type, $area, $date_create, $edit.$delete);

$response['data'][] = $value;
}
}

echo json_encode($response);

}

	// edit crawl post
public function edit_crawl(){
 $id = $this->uri->segment(4);
 if($id){
  $check = $this->Mpost->check_post_id($id);
  if($check==0){
   redirect('admin/post','refresh');
}
}else{
  redirect('admin/post','refresh');
}
$this->_data['page_title'] = "Cật nhật tin tức";
$this->_data['head_title'] = "Quản lý tin tức";
$this->_data['all_user'] = $this->Muser->get_all_user();
$this->_data['all_cate'] = $this->get_cate_recursive();

$this->_data['post_images'] = $this->Mpost->get_post_images($id);

$this->_data['list_province'] = $this->Mprovince->get_all_province();

$msg = '';
$this->form_validation->set_rules("post_title","Tên doanh nghiệp","required|trim");

if($this->form_validation->run() == true){
  $post_title = $this->input->post("post_title");
  if($this->Mpost->check_post_title_exists($post_title,$id)){
   $msg = array(
    "type" => "danger",
    "content" => "Tiêu đề bài viết đã tồn tại"
);
}else{
   $active = ($this->input->post("active"))?1:0;
   $feadtured_post = ($this->input->post("feadtured_post"))?1:0;
   $for_vip_user = ($this->input->post("for_vip_user"))?1:2;

   if ($this->input->post("crawler_type_switch"))
   {
    $for_vip_user = 0;
}

$cate_id = $this->input->post("cate_id");

$slug = $this->input->post("post_slug");
if(empty($slug)) $slug = $this->globals->change_to_slug($post_title);
$data = array(
    "thumbnail" => $this->input->post("thumbnail"),
    "post_title" => $post_title,
    "post_slug" => $slug,
    "post_content" => $this->input->post("post_content"),
    "cate_id" => json_encode( $cate_id ),
    "feadtured_post" => $feadtured_post,
    "active" => $active,
    "province_id" => $this->input->post("province_id"),
    "district_id" => $this->input->post("district_id"),
    "price" => $this->input->post("price"),
    "area" => $this->input->post("area"),
    "contact" => $this->input->post("contact"),
    "address" => $this->input->post("address"),
    "unit" => $this->input->post("unit"),
    "crawler_type" => $for_vip_user
);
$update_stt = $this->Mpost->update($id,$data);
if($update_stt){

    $this->Mpost->delete_post_images($id);

    if ($this->input->post('images'))
    {
     foreach ($this->input->post('images') as $item)
     {
      $this->Mpost->insert_post_images(array('image_url'=>$item, 'post_id'=>$id));
  }
}

$msg = array(
 "type" => "success",
 "content" => "Cập nhật thành công"
);
}else{
    $msg = array(
     "type" => "danger",
     "content" => "Cập nhật không thành công!"
 );
}
}
}
$this->_data['msg'] = $msg;
$this->_data['current_post'] = $this->Mpost->get_post_by('post_id',$id);

$this->load->view('admin/post/edit_post_crawl.php', $this->_data);
}
	// del post crawl
public function del_crawl(){
 $msg = '';
 $id = $this->uri->segment(4);
 if($id){
  $check = $this->Mpost->check_post_id($id);
  if($check==0){
   $msg = array(
    'type' => 'danger',
    'content' => 'Tin tức không tồn tại!'
);
}
}else{
  redirect('admin/post');
}

if($this->Mpost->delete($id)){
  $msg = array(
   'type' => 'success',
   'content' => 'Xóa tin tức thành công!'
);
}else{
  $msg = array(
   'type' => 'danger',
   'content' => 'Xóa không thành công!'
);
}

$this->session->set_flashdata('msg', $msg);
redirect('admin/post/manager_post_crawl');
}
}


/* End of file Home.php */
/* Location: ./application/controllers/admin/Home.php */